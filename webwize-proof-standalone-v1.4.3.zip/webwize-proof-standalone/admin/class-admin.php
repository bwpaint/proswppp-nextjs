<?php
defined( 'ABSPATH' ) || exit;

class WWPS_Admin {

    public static function init() {
        add_action( 'admin_menu',            array( __CLASS__, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
        add_action( 'wp_ajax_wwps_complete_task',       array( __CLASS__, 'ajax_complete_task' ) );
        add_action( 'wp_ajax_wwps_reopen_task',         array( __CLASS__, 'ajax_reopen_task' ) );
        add_action( 'wp_ajax_wwps_add_comment',         array( __CLASS__, 'ajax_add_comment' ) );
        add_action( 'wp_ajax_wwps_approve_page',        array( __CLASS__, 'ajax_approve_page' ) );
        add_action( 'wp_ajax_wwps_reset_token',         array( __CLASS__, 'ajax_reset_token' ) );
        add_action( 'wp_ajax_wwps_save_settings',       array( __CLASS__, 'ajax_save_settings' ) );
        add_action( 'wp_ajax_wwps_create_project',      array( __CLASS__, 'ajax_create_project' ) );
        // People & Teams
        add_action( 'wp_ajax_wwps_save_contact',        array( __CLASS__, 'ajax_save_contact' ) );
        add_action( 'wp_ajax_wwps_delete_contact',      array( __CLASS__, 'ajax_delete_contact' ) );
        add_action( 'wp_ajax_wwps_add_team_member',     array( __CLASS__, 'ajax_add_team_member' ) );
        add_action( 'wp_ajax_wwps_remove_team_member',  array( __CLASS__, 'ajax_remove_team_member' ) );
        add_action( 'wp_ajax_wwps_rename_team',         array( __CLASS__, 'ajax_rename_team' ) );
        // Notification settings
        add_action( 'wp_ajax_wwps_save_notif_settings', array( __CLASS__, 'ajax_save_notif_settings' ) );
        // Clarifying question
        add_action( 'wp_ajax_wwps_send_clarifying_question', array( __CLASS__, 'ajax_send_clarifying_question' ) );
    }

    public static function register_menu() {
        // Tasks is the landing page — clicking "WW Proof" in the sidebar goes straight to tasks
        add_menu_page(
            'WebWize Proof',
            'WW Proof',
            'manage_options',
            'wwps-tasks',
            array( __CLASS__, 'page_tasks' ),
            'dashicons-visibility',
            30
        );
        add_submenu_page( 'wwps-tasks', 'Tasks',              'Tasks',              'manage_options', 'wwps-tasks',          array( __CLASS__, 'page_tasks' ) );
        add_submenu_page( 'wwps-tasks', 'Projects',           'Projects',           'manage_options', 'wwps-projects',       array( __CLASS__, 'page_projects' ) );
        add_submenu_page( 'wwps-tasks', 'Settings',           'Settings',           'manage_options', 'wwps-settings',       array( __CLASS__, 'page_settings' ) );
        add_submenu_page( 'wwps-tasks', 'People & Teams',     'People & Teams',     'manage_options', 'wwps-people',         array( __CLASS__, 'page_people' ) );
        add_submenu_page( 'wwps-tasks', 'Notification Setup', 'Notification Setup', 'manage_options', 'wwps-notif-settings', array( __CLASS__, 'page_notif_settings' ) );
        add_submenu_page( 'wwps-tasks', 'Notification Log',   'Notification Log',   'manage_options', 'wwps-log',            array( __CLASS__, 'page_log' ) );
    }

    public static function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'wwps' ) === false ) return;
        wp_enqueue_style(  'wwps-admin', WWPS_PLUGIN_URL . 'assets/admin.css', array(), WWPS_VERSION );
        wp_enqueue_script( 'wwps-admin', WWPS_PLUGIN_URL . 'assets/admin.js',  array( 'jquery' ), WWPS_VERSION, true );
        wp_localize_script( 'wwps-admin', 'wwpsAdmin', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'wwps_admin' ),
        ) );
    }

    // Pages

    public static function page_projects() {
        global $wpdb;
        $projects = $wpdb->get_results( "SELECT * FROM " . WWPS_DB::projects_table() . " ORDER BY created_at DESC" );
        include WWPS_PLUGIN_DIR . 'admin/views/projects.php';
    }

    public static function page_tasks() {
        global $wpdb;
        $project_id = (int) ( isset( $_GET['project'] ) ? $_GET['project'] : 0 );
        $status     = sanitize_text_field( isset( $_GET['status'] )   ? $_GET['status']   : 'open' );
        $priority   = sanitize_text_field( isset( $_GET['priority'] ) ? $_GET['priority'] : 'all' );
        $view       = sanitize_text_field( isset( $_GET['view'] )     ? $_GET['view']     : 'list' );

        $projects = $wpdb->get_results( "SELECT * FROM " . WWPS_DB::projects_table() . " ORDER BY name ASC" );

        if ( ! $project_id && ! empty( $projects ) ) {
            $project_id = (int) $projects[0]->id;
        }

        $project = $project_id ? WWPS_Tokens::get_project_by_id( $project_id ) : null;
        $tasks   = $project_id ? WWPS_Tasks::get_for_project( $project_id, compact( 'status', 'priority' ) ) : array();
        $pages   = $project_id ? $wpdb->get_results( $wpdb->prepare(
            "SELECT DISTINCT page_url, page_title FROM " . WWPS_DB::tasks_table() . " WHERE project_id = %d",
            $project_id
        ) ) : array();

        $detail_task     = null;
        $detail_comments = array();
        if ( isset( $_GET['task'] ) ) {
            $detail_task     = WWPS_Tasks::get( (int) $_GET['task'] );
            $detail_comments = $detail_task ? WWPS_Tasks::get_comments( $detail_task->id ) : array();
        }

        // Dashboard stat tiles — unfiltered counts for the selected project
        $stats = array(
            'open'          => 0,
            'critical'      => 0,
            'hot'           => 0,
            'completed'     => 0,
            'pages_pending' => 0,
        );
        if ( $project_id ) {
            $tt = WWPS_DB::tasks_table();
            $pg = WWPS_DB::pages_table();
            $stats['open']          = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tt WHERE project_id = %d AND status = 'open'",      $project_id ) );
            $stats['critical']      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tt WHERE project_id = %d AND status = 'open' AND priority = 'critical'", $project_id ) );
            $stats['hot']           = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tt WHERE project_id = %d AND status = 'open' AND priority = 'hot'",      $project_id ) );
            $stats['completed']     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tt WHERE project_id = %d AND status = 'completed'", $project_id ) );
            $stats['pages_pending'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $pg WHERE project_id = %d AND status != 'approved'", $project_id ) );
        }

        include WWPS_PLUGIN_DIR . 'admin/views/tasks.php';
    }

    public static function page_settings() {
        global $wpdb;
        $projects   = $wpdb->get_results( "SELECT * FROM " . WWPS_DB::projects_table() . " ORDER BY name ASC" );
        $first_id   = ! empty( $projects ) ? $projects[0]->id : 0;
        $project_id = (int) ( isset( $_GET['project'] ) ? $_GET['project'] : $first_id );
        $project    = $project_id ? WWPS_Tokens::get_project_by_id( $project_id ) : null;
        include WWPS_PLUGIN_DIR . 'admin/views/settings.php';
    }

    public static function page_log() {
        global $wpdb;
        $log = $wpdb->get_results(
            "SELECT l.*, p.name as project_name FROM " . WWPS_DB::log_table() . " l
             LEFT JOIN " . WWPS_DB::projects_table() . " p ON p.id = l.project_id
             ORDER BY l.created_at DESC LIMIT 200"
        );
        include WWPS_PLUGIN_DIR . 'admin/views/log.php';
    }

    // AJAX Handlers

    public static function ajax_complete_task() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $task_id = (int) ( isset( $_POST['task_id'] ) ? $_POST['task_id'] : 0 );
        $task    = WWPS_Tasks::get( $task_id );
        $user    = wp_get_current_user();
        $done    = WWPS_Tasks::complete( $task_id, $user->display_name );

        if ( $done && $task ) {
            $project = WWPS_Tokens::get_project_by_id( (int) $task->project_id );
            do_action( 'wwps_task_completed', $task_id, $project );
        }

        wp_send_json_success( array( 'completed' => $done ) );
    }

    public static function ajax_reopen_task() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
        $task_id = (int) ( isset( $_POST['task_id'] ) ? $_POST['task_id'] : 0 );
        wp_send_json_success( array( 'reopened' => WWPS_Tasks::reopen( $task_id ) ) );
    }

    public static function ajax_add_comment() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $user        = wp_get_current_user();
        $task_id     = (int) ( isset( $_POST['task_id'] ) ? $_POST['task_id'] : 0 );
        $is_internal = (int) ( isset( $_POST['is_internal'] ) ? $_POST['is_internal'] : 0 );

        $comment_id = WWPS_Tasks::add_comment( $task_id, array(
            'author_name'  => $user->display_name,
            'author_email' => $user->user_email,
            'body'         => sanitize_textarea_field( isset( $_POST['body'] ) ? $_POST['body'] : '' ),
            'is_internal'  => $is_internal,
        ) );

        wp_send_json_success( array( 'comment_id' => $comment_id ) );
    }

    public static function ajax_approve_page() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        global $wpdb;
        $project_id = (int) ( isset( $_POST['project_id'] ) ? $_POST['project_id'] : 0 );
        $page_url   = sanitize_url( isset( $_POST['page_url'] ) ? $_POST['page_url'] : '' );
        $table      = WWPS_DB::pages_table();

        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE project_id = %d AND page_url = %s", $project_id, $page_url
        ) );

        $user = wp_get_current_user();
        if ( $existing ) {
            $wpdb->update( $table, array(
                'status'      => 'approved',
                'approved_by' => $user->display_name,
                'approved_at' => current_time( 'mysql' ),
            ), array( 'id' => $existing ) );
        } else {
            $wpdb->insert( $table, array(
                'project_id'  => $project_id,
                'page_url'    => $page_url,
                'status'      => 'approved',
                'approved_by' => $user->display_name,
                'approved_at' => current_time( 'mysql' ),
            ) );
            $wpdb->query( $wpdb->prepare(
                "UPDATE " . WWPS_DB::projects_table() . " SET pages_approved = pages_approved + 1 WHERE id = %d",
                $project_id
            ) );
        }

        wp_send_json_success();
    }

    public static function ajax_reset_token() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $project_id = (int) ( isset( $_POST['project_id'] ) ? $_POST['project_id'] : 0 );
        $type       = sanitize_text_field( isset( $_POST['type'] ) ? $_POST['type'] : 'proof' );

        $token = ( $type === 'review' )
            ? WWPS_Tokens::regenerate_review_token( $project_id )
            : WWPS_Tokens::regenerate_proof_token( $project_id );

        wp_send_json_success( array( 'token' => $token ) );
    }

    public static function ajax_save_settings() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $project_id = (int) ( isset( $_POST['project_id'] ) ? $_POST['project_id'] : 0 );
        if ( ! $project_id ) {
            update_option( 'wwps_overdue_hours', (int) ( isset( $_POST['overdue_hours'] ) ? $_POST['overdue_hours'] : 48 ) );
            wp_send_json_success( array( 'message' => 'Settings saved.' ) );
            return;
        }

        global $wpdb;
        $frontend = isset( $_POST['frontend_url'] ) ? rtrim( esc_url_raw( $_POST['frontend_url'] ), '/' ) : '';
        $wpdb->update( WWPS_DB::projects_table(), array(
            'name'          => sanitize_text_field( isset( $_POST['name'] )          ? $_POST['name']          : '' ),
            'client_name'   => sanitize_text_field( isset( $_POST['client_name'] )   ? $_POST['client_name']   : '' ),
            'client_emails' => sanitize_text_field( isset( $_POST['client_emails'] ) ? $_POST['client_emails'] : '' ),
            'support_email' => sanitize_email(      isset( $_POST['support_email'] ) ? $_POST['support_email'] : '' ),
            'frontend_url'  => $frontend,
        ), array( 'id' => $project_id ) );

        wp_send_json_success( array( 'message' => 'Project settings saved.' ) );
    }

    public static function ajax_create_project() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        global $wpdb;
        $wpdb->insert( WWPS_DB::projects_table(), array(
            'name'          => sanitize_text_field( isset( $_POST['name'] )          ? $_POST['name']          : 'New Project' ),
            'client_name'   => sanitize_text_field( isset( $_POST['client_name'] )   ? $_POST['client_name']   : '' ),
            'client_emails' => sanitize_text_field( isset( $_POST['client_emails'] ) ? $_POST['client_emails'] : '' ),
            'support_email' => sanitize_email(      isset( $_POST['support_email'] ) ? $_POST['support_email'] : get_option( 'admin_email' ) ),
            'frontend_url'  => '',
            'proof_token'   => bin2hex( random_bytes( 32 ) ),
            'review_token'  => bin2hex( random_bytes( 32 ) ),
        ) );

        wp_send_json_success( array( 'project_id' => $wpdb->insert_id ) );
    }

    // -------------------------------------------------------------------------
    // People & Teams page
    // -------------------------------------------------------------------------

    public static function page_people() {
        $contacts = WWPS_Contacts::get_all();
        $teams    = WWPS_Teams::get_all();
        include WWPS_PLUGIN_DIR . 'admin/views/people.php';
    }

    public static function ajax_save_contact() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $id    = (int) ( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
        $name  = sanitize_text_field( isset( $_POST['name'] )  ? $_POST['name']  : '' );
        $email = sanitize_email(      isset( $_POST['email'] ) ? $_POST['email'] : '' );

        if ( empty( $name ) || empty( $email ) ) {
            wp_send_json_error( 'Name and email are required.' );
        }

        if ( $id ) {
            WWPS_Contacts::update( $id, $name, $email );
            wp_send_json_success( array( 'id' => $id, 'name' => $name, 'email' => $email ) );
        } else {
            $new_id = WWPS_Contacts::create( $name, $email );
            if ( ! $new_id ) {
                wp_send_json_error( 'Could not create contact — email may already exist.' );
            }
            wp_send_json_success( array( 'id' => $new_id, 'name' => $name, 'email' => $email ) );
        }
    }

    public static function ajax_delete_contact() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
        $id = (int) ( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
        WWPS_Contacts::delete( $id );
        wp_send_json_success();
    }

    public static function ajax_add_team_member() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
        $team_id    = (int) ( isset( $_POST['team_id'] )    ? $_POST['team_id']    : 0 );
        $contact_id = (int) ( isset( $_POST['contact_id'] ) ? $_POST['contact_id'] : 0 );
        WWPS_Teams::add_member( $team_id, $contact_id );
        wp_send_json_success();
    }

    public static function ajax_remove_team_member() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
        $team_id    = (int) ( isset( $_POST['team_id'] )    ? $_POST['team_id']    : 0 );
        $contact_id = (int) ( isset( $_POST['contact_id'] ) ? $_POST['contact_id'] : 0 );
        WWPS_Teams::remove_member( $team_id, $contact_id );
        wp_send_json_success();
    }

    public static function ajax_rename_team() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
        $team_id = (int) ( isset( $_POST['team_id'] ) ? $_POST['team_id'] : 0 );
        $name    = sanitize_text_field( isset( $_POST['name'] ) ? $_POST['name'] : '' );
        $ok      = WWPS_Teams::update_name( $team_id, $name );
        if ( ! $ok ) {
            wp_send_json_error( 'Team name is locked or not found.' );
        }
        wp_send_json_success();
    }

    // -------------------------------------------------------------------------
    // Notification Settings page
    // -------------------------------------------------------------------------

    public static function page_notif_settings() {
        $settings = WWPS_Notification_Settings::get_all();
        $teams    = WWPS_Teams::get_all();
        $labels   = WWPS_Notification_Settings::event_labels();
        $is_admin = current_user_can( 'manage_options' );
        // Build assigned teams per event
        $assigned = array();
        foreach ( array_keys( $labels ) as $event ) {
            $assigned[ $event ] = WWPS_Teams::get_for_event( $event );
        }
        include WWPS_PLUGIN_DIR . 'admin/views/notif-settings.php';
    }

    public static function ajax_save_notif_settings() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $action_sub = sanitize_text_field( isset( $_POST['sub_action'] ) ? $_POST['sub_action'] : '' );

        if ( $action_sub === 'toggle' ) {
            $event   = sanitize_text_field( isset( $_POST['event_type'] ) ? $_POST['event_type'] : '' );
            $enabled = (int) ( isset( $_POST['enabled'] ) ? $_POST['enabled'] : 1 );
            WWPS_Notification_Settings::set_enabled( $event, $enabled );
            wp_send_json_success();
        }

        if ( $action_sub === 'add_team' ) {
            $event   = sanitize_text_field( isset( $_POST['event_type'] ) ? $_POST['event_type'] : '' );
            $team_id = (int) ( isset( $_POST['team_id'] ) ? $_POST['team_id'] : 0 );
            WWPS_Teams::assign_to_event( $event, $team_id );
            wp_send_json_success();
        }

        if ( $action_sub === 'remove_team' ) {
            $event   = sanitize_text_field( isset( $_POST['event_type'] ) ? $_POST['event_type'] : '' );
            $team_id = (int) ( isset( $_POST['team_id'] ) ? $_POST['team_id'] : 0 );
            // Webmaster team (is_name_locked) can only be removed by WordPress admins
            $team = WWPS_Teams::get( $team_id );
            if ( $team && (int) $team->is_name_locked === 1 && ! current_user_can( 'manage_options' ) ) {
                wp_send_json_error( 'Only WordPress administrators can remove the Webmaster team from notifications.' );
                return;
            }
            WWPS_Teams::remove_from_event( $event, $team_id );
            wp_send_json_success();
        }

        wp_send_json_error( 'Unknown sub_action' );
    }

    // -------------------------------------------------------------------------
    // Clarifying question
    // -------------------------------------------------------------------------

    public static function ajax_send_clarifying_question() {
        check_ajax_referer( 'wwps_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $task_id  = (int) ( isset( $_POST['task_id'] ) ? $_POST['task_id'] : 0 );
        $question = sanitize_textarea_field( isset( $_POST['question'] ) ? $_POST['question'] : '' );

        if ( ! $task_id || empty( $question ) ) {
            wp_send_json_error( 'Task ID and question are required.' );
        }

        $task = WWPS_Tasks::get( $task_id );
        if ( ! $task ) {
            wp_send_json_error( 'Task not found.' );
        }

        $to = sanitize_email( $task->author_email );
        if ( ! is_email( $to ) ) {
            wp_send_json_error( 'Task submitter has no email address on file.' );
        }

        $project      = WWPS_Tokens::get_project_by_id( (int) $task->project_id );
        $project_name = $project ? esc_html( $project->name ) : 'your project';
        $ticket_id    = esc_html( $task->ticket_id );
        $admin_url    = admin_url( 'admin.php?page=wwps-tasks&task=' . $task_id );
        $sender_name  = wp_get_current_user()->display_name;
        $reply_body   = rawurlencode( "Re: [{$ticket_id}] — {$question}\n\n[Your answer here]" );
        $mailto       = "mailto:{$to}?subject=" . rawurlencode( "Re: [{$ticket_id}]" ) . "&body={$reply_body}";
        $from_email   = get_option( 'admin_email' );
        $from_name    = get_option( 'blogname' );

        $subject = "[{$ticket_id}] Question about your feedback — {$project_name}";

        $body  = "Hi {$task->author_name},\n\n";
        $body .= "We have a question about the feedback you submitted ({$ticket_id}):\n\n";
        $body .= "\"{$question}\"\n\n";
        $body .= "Please reply to this email or click the link below:\n";
        $body .= $admin_url . "\n\n";
        $body .= "Thank you,\n{$sender_name}\n{$from_name}";

        $headers = array(
            'Content-Type: text/plain; charset=UTF-8',
            "From: {$from_name} <{$from_email}>",
            "Reply-To: {$from_name} <{$from_email}>",
        );

        $sent = wp_mail( $to, $subject, $body, $headers );

        // Log internally as an internal comment
        WWPS_Tasks::add_comment( $task_id, array(
            'author_name'  => $sender_name,
            'author_email' => $from_email,
            'body'         => "[Clarifying question sent to {$task->author_name} ({$to})]\n\n{$question}",
            'is_internal'  => 1,
        ) );

        if ( $sent ) {
            wp_send_json_success( array( 'message' => "Question sent to {$task->author_name} ({$to})." ) );
        } else {
            wp_send_json_error( 'Email could not be sent. Check your WordPress mail configuration.' );
        }
    }
}
