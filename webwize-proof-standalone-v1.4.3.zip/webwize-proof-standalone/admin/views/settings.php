<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap wwps-wrap">
    <h1>WebWize Proof &mdash; Settings</h1>

    <?php if ( ! empty( $projects ) ) : ?>
    <div class="wwps-tab-bar">
        <?php foreach ( $projects as $p ) : ?>
            <a href="?page=wwps-settings&project=<?php echo (int) $p->id; ?>"
               class="wwps-tab <?php echo (int) $p->id === $project_id ? 'active' : ''; ?>">
                <?php echo esc_html( $p->name ); ?>
            </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if ( $project ) : ?>
    <div class="wwps-card">
        <h2><?php echo esc_html( $project->name ); ?> &mdash; Project Settings</h2>
        <table class="form-table">
            <tr>
                <th>Project Name</th>
                <td><input type="text" id="wwps-proj-name" class="regular-text" value="<?php echo esc_attr( $project->name ); ?>"></td>
            </tr>
            <tr>
                <th>Client Name</th>
                <td><input type="text" id="wwps-proj-client" class="regular-text" value="<?php echo esc_attr( $project->client_name ); ?>"></td>
            </tr>
            <tr>
                <th>Client Emails</th>
                <td>
                    <input type="text" id="wwps-proj-emails" class="regular-text" value="<?php echo esc_attr( $project->client_emails ); ?>">
                    <p class="description">Comma-separated. Clients receive task submitted notifications.</p>
                </td>
            </tr>
            <tr>
                <th>Support Email</th>
                <td>
                    <input type="email" id="wwps-proj-support" class="regular-text" value="<?php echo esc_attr( $project->support_email ); ?>">
                    <p class="description">WebWize team receives all task notifications here.</p>
                </td>
            </tr>
            <tr>
                <th>Frontend URL <span style="color:#e94560;">(headless)</span></th>
                <td>
                    <input type="url" id="wwps-proj-frontend" class="regular-text" value="<?php echo esc_attr( $project->frontend_url ); ?>" placeholder="https://www2dproswp.com">
                    <p class="description">The React / headless frontend URL. When set, proof and review links point here instead of the WordPress domain. Leave blank for standard WordPress sites.</p>
                </td>
            </tr>
        </table>
        <button class="button button-primary wwps-save-settings" data-project="<?php echo (int) $project->id; ?>">Save Project Settings</button>
        <span class="wwps-save-msg" style="display:none;margin-left:10px;color:green;">&#10003; Saved</span>
    </div>

    <div class="wwps-card">
        <h2>Proof Tokens</h2>
        <p class="description">Share the <strong>Proof URL</strong> with your client. Use the <strong>Review URL</strong> internally to see pins and manage tasks.</p>
        <table class="form-table">
            <tr>
                <th>Proof URL <span style="color:#e94560;">(client)</span></th>
                <td>
                    <code id="wwps-proof-url"><?php echo esc_html( WWPS_Tokens::get_proof_url( $project ) ); ?></code><br><br>
                    <button class="button wwps-copy-btn" data-copy="<?php echo esc_attr( WWPS_Tokens::get_proof_url( $project ) ); ?>">Copy</button>
                    <a href="<?php echo esc_url( WWPS_Tokens::get_proof_url( $project ) ); ?>" target="_blank" class="button" style="color:#e94560;font-weight:600;">&#9654; Open Proof URL</a>
                    <button class="button wwps-reset-token-btn" data-project="<?php echo (int) $project->id; ?>" data-type="proof"
                            onclick="return confirm('Reset the proof token? The old link will stop working immediately.')">&#8635; Reset Token</button>
                </td>
            </tr>
            <tr>
                <th>Review URL <span style="color:#3182ce;">(team)</span></th>
                <td>
                    <code id="wwps-review-url"><?php echo esc_html( WWPS_Tokens::get_review_url( $project ) ); ?></code><br><br>
                    <button class="button wwps-copy-btn" data-copy="<?php echo esc_attr( WWPS_Tokens::get_review_url( $project ) ); ?>">Copy</button>
                    <a href="<?php echo esc_url( WWPS_Tokens::get_review_url( $project ) ); ?>" target="_blank" class="button" style="color:#3182ce;font-weight:600;">&#9654; Open Review URL</a>
                    <button class="button wwps-reset-token-btn" data-project="<?php echo (int) $project->id; ?>" data-type="review"
                            onclick="return confirm('Reset the review token? Update your bookmarks after resetting.')">&#8635; Reset Token</button>
                </td>
            </tr>
        </table>
    </div>

    <?php if ( ! empty( $project->frontend_url ) ) : ?>
    <div class="wwps-card">
        <h2>Headless Embed Snippet</h2>
        <p>Paste this <code>&lt;script&gt;</code> tag into your React app's <code>public/index.html</code> just before the closing <code>&lt;/body&gt;</code> tag. It self-activates only when a proof or review token is present in the URL &mdash; invisible to normal visitors.</p>
        <?php
            $wp_api = rtrim( get_bloginfo( 'url' ), '/' );
            $js_url = WWPS_PLUGIN_URL . 'assets/proof.js?v=' . WWPS_VERSION;
        ?>
        <textarea class="large-text" rows="12" readonly onclick="this.select()" style="font-family:monospace;font-size:12px;background:#0f172a;color:#e2e8f0;border-radius:4px;padding:12px;"><?php echo esc_textarea( '<script>
(function () {
  var p = new URLSearchParams(window.location.search);
  var proof  = p.get(\'proof\');
  var review = p.get(\'review\');
  if (!proof && !review) return;
  window.wwpsConfig = {
    ajaxUrl:     \'' . $wp_api . '/wp-json/webwize-proof/v1\',
    proofToken:  proof  || \'\',
    reviewToken: review || \'\',
    mode:        review ? \'review\' : \'proof\',
    pageUrl:     window.location.href.replace(/[?&](proof|review)=[^&]*/g, \'\').replace(/[?&]$/, \'\'),
    pageTitle:   document.title,
    nonce:       \'\'
  };
  var s = document.createElement(\'script\');
  s.src = \'' . $js_url . '\';
  document.body.appendChild(s);
})();
</script>' ); ?></textarea>
        <p class="description" style="margin-top:8px;">Click inside the box to select all, then copy. After pasting, rebuild/redeploy your React app. No other changes needed.</p>
    </div>
    <?php endif; ?>

    <div class="wwps-card">
        <h2>Page Approvals</h2>
        <?php
        global $wpdb;
        $pages = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . WWPS_DB::pages_table() . " WHERE project_id = %d ORDER BY page_url ASC",
            $project->id
        ) );
        ?>
        <?php if ( empty( $pages ) ) : ?>
            <p class="wwps-muted">No pages tracked yet. Pages appear here when the first task is submitted on them.</p>
        <?php else : ?>
        <table class="wp-list-table widefat fixed striped wwps-table">
            <thead><tr><th>Page</th><th>Status</th><th>Approved By</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ( $pages as $pg ) : ?>
            <tr>
                <td><a href="<?php echo esc_url( $pg->page_url ); ?>" target="_blank"><?php echo esc_html( $pg->page_title ? $pg->page_title : $pg->page_url ); ?></a></td>
                <td><span class="wwps-status-badge <?php echo esc_attr( $pg->status ); ?>"><?php echo ucfirst( $pg->status ); ?></span></td>
                <td><?php echo esc_html( $pg->approved_by ); ?> <?php echo $pg->approved_at ? '@ ' . esc_html( $pg->approved_at ) : ''; ?></td>
                <td>
                    <?php if ( $pg->status !== 'approved' ) : ?>
                    <button class="button button-small wwps-approve-page-btn"
                            data-project="<?php echo (int) $project->id; ?>"
                            data-url="<?php echo esc_attr( $pg->page_url ); ?>">&#10003; Approve Page</button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="wwps-card">
        <h2>Global Settings</h2>
        <table class="form-table">
            <tr>
                <th>Overdue threshold (hours)</th>
                <td>
                    <input type="number" id="wwps-overdue-hours" class="small-text" value="<?php echo (int) get_option( 'wwps_overdue_hours', 48 ); ?>">
                    <p class="description">Tasks open longer than this are included in the daily overdue digest. Default: 48 hours.</p>
                </td>
            </tr>
        </table>
        <button class="button button-primary wwps-save-settings" data-project="0">Save Global Settings</button>
        <span class="wwps-save-msg" style="display:none;margin-left:10px;color:green;">&#10003; Saved</span>
    </div>
</div>
