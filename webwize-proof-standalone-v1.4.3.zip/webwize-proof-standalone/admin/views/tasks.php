<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap wwps-wrap">

<?php if ( $detail_task ) :
    $task = $detail_task;
    $back = admin_url( 'admin.php?page=wwps-tasks&project=' . $task->project_id );
    $p    = WWPS_Tokens::get_project_by_id( (int) $task->project_id );
?>
    <h1><a href="<?php echo esc_url( $back ); ?>" style="text-decoration:none;">&larr; Tasks</a> / <?php echo esc_html( $task->ticket_id ); ?></h1>

    <div class="wwps-detail-grid">
        <div class="wwps-detail-main">
            <div class="wwps-card">
                <div class="wwps-detail-header">
                    <?php echo WWPS_Tasks::priority_badge( $task->priority ); ?>
                    <span class="wwps-status-badge <?php echo esc_attr( $task->status ); ?>"><?php echo ucfirst( $task->status ); ?></span>
                    <code class="wwps-ticket"><?php echo esc_html( $task->ticket_id ); ?></code>
                </div>

                <table class="wwps-meta-table">
                    <tr><th>Page</th><td><a href="<?php echo esc_url( $task->page_url ); ?>" target="_blank"><?php echo esc_html( $task->page_title ? $task->page_title : $task->page_url ); ?></a></td></tr>
                    <tr><th>Element</th><td><code><?php echo esc_html( $task->element_tag ); ?></code>
                        <?php if ( $task->element_text_before ) : ?>
                            &mdash; <em>"&hellip;<?php echo esc_html( $task->element_text_before ); ?>&hellip;"</em>
                        <?php endif; ?>
                    </td></tr>
                    <tr><th>Position</th><td><?php echo esc_html( $task->scroll_percent ); ?>% down the page &middot; <?php echo esc_html( $task->viewport_x_percent ); ?>% from left</td></tr>
                    <tr><th>Device</th><td><?php echo esc_html( ucfirst( $task->device_type ) ); ?> &middot; <?php echo esc_html( $task->browser ); ?> on <?php echo esc_html( $task->os ); ?> &middot; <?php echo esc_html( $task->viewport_width ); ?>&times;<?php echo esc_html( $task->viewport_height ); ?></td></tr>
                    <tr><th>Submitted by</th><td><?php echo esc_html( $task->author_name ); ?> &lt;<?php echo esc_html( $task->author_email ); ?>&gt;</td></tr>
                    <tr><th>Submitted</th><td><?php echo esc_html( $task->created_at ); ?></td></tr>
                    <?php if ( $task->status === 'completed' ) : ?>
                    <tr><th>Completed by</th><td><?php echo esc_html( $task->completed_by ); ?> at <?php echo esc_html( $task->completed_at ); ?></td></tr>
                    <?php endif; ?>
                </table>

                <div class="wwps-comment-original">
                    <strong>Original Comment:</strong>
                    <p><?php echo nl2br( esc_html( $task->comment ) ); ?></p>
                </div>

                <?php if ( ! empty( $task->image_url ) ) : ?>
                <div class="wwps-comment-original" style="margin-top:16px;">
                    <strong>Attached Image:</strong>
                    <div style="margin-top:8px;">
                        <a href="#" onclick="wwpsOpenImg('<?php echo esc_js( $task->image_url ); ?>');return false;">
                            <img src="<?php echo esc_url( $task->image_url ); ?>"
                                 style="max-width:100%;max-height:280px;border-radius:4px;border:1px solid #e2e8f0;display:block;cursor:zoom-in;"
                                 alt="Attached image">
                        </a>
                        <a href="<?php echo esc_url( $task->image_url ); ?>" target="_blank" style="font-size:12px;margin-top:6px;display:inline-block;">Open full size &#8599;</a>
                    </div>
                </div>
                <?php endif; ?>

                <div class="wwps-actions">
                    <?php if ( $task->status === 'open' ) : ?>
                        <button class="button button-primary wwps-complete-btn" data-task="<?php echo (int) $task->id; ?>">&#10003; Mark Complete</button>
                    <?php else : ?>
                        <button class="button wwps-reopen-btn" data-task="<?php echo (int) $task->id; ?>">&#8635; Re-open Task</button>
                    <?php endif; ?>

                    <?php if ( $p ) : ?>
                        <a href="<?php echo esc_url( WWPS_Tokens::get_review_url( $p, $task->page_url ) ); ?>" target="_blank" class="button">Open Page in Review Mode &rarr;</a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="wwps-card">
                <h3>Comments</h3>
                <?php if ( empty( $detail_comments ) ) : ?>
                    <p class="wwps-muted">No comments yet.</p>
                <?php else : ?>
                    <?php foreach ( $detail_comments as $c ) : ?>
                    <div class="wwps-comment <?php echo $c->is_internal ? 'internal' : ''; ?>">
                        <?php if ( $c->is_internal ) : ?><span class="wwps-internal-badge">Internal</span><?php endif; ?>
                        <strong><?php echo esc_html( $c->author_name ); ?></strong>
                        <span class="wwps-muted"><?php echo esc_html( $c->created_at ); ?></span>
                        <p><?php echo nl2br( esc_html( $c->body ) ); ?></p>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>

                <div class="wwps-add-comment">
                    <h4>Add Note</h4>
                    <textarea id="wwps-comment-body" rows="4" class="large-text" placeholder="Add a reply or internal note..."></textarea>
                    <label><input type="checkbox" id="wwps-comment-internal"> Internal note (not visible to client)</label>
                    <br><br>
                    <button class="button button-primary wwps-comment-submit" data-task="<?php echo (int) $task->id; ?>">Add Note</button>
                </div>
            </div>
        </div>

        <div class="wwps-detail-sidebar">
            <div class="wwps-card">
                <h4>Quick Info</h4>
                <p><strong>Project:</strong><br><?php echo $p ? esc_html( $p->name ) : '&mdash;'; ?></p>
                <p><strong>Priority:</strong><br><?php echo WWPS_Tasks::priority_badge( $task->priority ); ?></p>
                <p><strong>Status:</strong><br><span class="wwps-status-badge <?php echo esc_attr( $task->status ); ?>"><?php echo ucfirst( $task->status ); ?></span></p>
                <?php if ( $task->element_selector ) : ?>
                <p><strong>Selector:</strong><br><code style="font-size:11px;word-break:break-all;"><?php echo esc_html( $task->element_selector ); ?></code></p>
                <?php endif; ?>
            </div>

            <?php if ( is_email( $task->author_email ) ) : ?>
            <div class="wwps-card" style="margin-top:16px;">
                <h4 style="margin-top:0;">Ask a Clarifying Question</h4>
                <p style="font-size:12px;color:#666;margin-top:0;">Send a question to <strong><?php echo esc_html( $task->author_name ); ?></strong> at <em><?php echo esc_html( $task->author_email ); ?></em>. A copy of your question is saved as an internal note.</p>
                <textarea id="wwps-clarify-body" rows="4" class="large-text" placeholder="What exactly did you mean by...?"></textarea>
                <br>
                <button class="button button-secondary wwps-clarify-btn" data-task="<?php echo (int) $task->id; ?>" style="margin-top:8px;">&#9993; Send Question</button>
                <p id="wwps-clarify-msg" style="font-size:12px;margin:6px 0 0;"></p>
            </div>
            <?php else : ?>
            <div class="wwps-card" style="margin-top:16px;">
                <h4 style="margin-top:0;">Clarifying Question</h4>
                <p style="font-size:12px;color:#999;">No email address on file for this submitter.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

<?php else : ?>
    <h1 class="wp-heading-inline">Tasks</h1>
    <hr class="wp-header-end">

    <?php if ( $project_id ) : ?>
    <div class="wwps-stat-tiles">
        <a class="wwps-stat-tile wwps-tile-open"
           href="<?php echo esc_url( admin_url( 'admin.php?page=wwps-tasks&project=' . $project_id . '&status=open&priority=all' ) ); ?>">
            <div class="wwps-tile-number"><?php echo (int) $stats['open']; ?></div>
            <div class="wwps-tile-label">Open Tasks</div>
            <div class="wwps-tile-sub">Waiting for action</div>
        </a>
        <a class="wwps-stat-tile wwps-tile-critical"
           href="<?php echo esc_url( admin_url( 'admin.php?page=wwps-tasks&project=' . $project_id . '&status=open&priority=critical' ) ); ?>">
            <div class="wwps-tile-number"><?php echo (int) $stats['critical']; ?></div>
            <div class="wwps-tile-label">Critical</div>
            <div class="wwps-tile-sub">Highest priority</div>
        </a>
        <a class="wwps-stat-tile wwps-tile-hot"
           href="<?php echo esc_url( admin_url( 'admin.php?page=wwps-tasks&project=' . $project_id . '&status=open&priority=hot' ) ); ?>">
            <div class="wwps-tile-number"><?php echo (int) $stats['hot']; ?></div>
            <div class="wwps-tile-label">Hot</div>
            <div class="wwps-tile-sub">Needs attention soon</div>
        </a>
        <a class="wwps-stat-tile wwps-tile-completed"
           href="<?php echo esc_url( admin_url( 'admin.php?page=wwps-tasks&project=' . $project_id . '&status=completed&priority=all' ) ); ?>">
            <div class="wwps-tile-number"><?php echo (int) $stats['completed']; ?></div>
            <div class="wwps-tile-label">Completed</div>
            <div class="wwps-tile-sub">Resolved &amp; closed</div>
        </a>
        <a class="wwps-stat-tile wwps-tile-pages"
           href="<?php echo esc_url( admin_url( 'admin.php?page=wwps-projects&project=' . $project_id ) ); ?>">
            <div class="wwps-tile-number"><?php echo (int) $stats['pages_pending']; ?></div>
            <div class="wwps-tile-label">Pages to Approve</div>
            <div class="wwps-tile-sub">Awaiting sign-off</div>
        </a>
    </div>
    <style>
    .wwps-stat-tiles {
        display: flex;
        gap: 14px;
        flex-wrap: wrap;
        margin: 18px 0 24px;
    }
    .wwps-stat-tile {
        flex: 1 1 140px;
        min-width: 120px;
        max-width: 200px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 20px 14px 16px;
        border-radius: 10px;
        text-decoration: none;
        color: #fff;
        box-shadow: 0 4px 18px rgba(0,0,0,.18);
        transition: transform .15s, box-shadow .15s;
        position: relative;
        overflow: hidden;
    }
    .wwps-stat-tile:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 28px rgba(0,0,0,.26);
        color: #fff;
    }
    .wwps-tile-number {
        font-size: 48px;
        font-weight: 800;
        line-height: 1;
        letter-spacing: -2px;
        text-shadow: 0 2px 6px rgba(0,0,0,.18);
    }
    .wwps-tile-label {
        font-size: 13px;
        font-weight: 700;
        margin-top: 6px;
        text-transform: uppercase;
        letter-spacing: .5px;
    }
    .wwps-tile-sub {
        font-size: 11px;
        margin-top: 4px;
        opacity: .82;
        text-align: center;
    }
    .wwps-tile-open     { background: linear-gradient(135deg, #f6971e 0%, #e07c10 100%); }
    .wwps-tile-critical { background: linear-gradient(135deg, #e53e3e 0%, #c53030 100%); }
    .wwps-tile-hot      { background: linear-gradient(135deg, #805ad5 0%, #6b46c1 100%); }
    .wwps-tile-completed{ background: linear-gradient(135deg, #38a169 0%, #276749 100%); }
    .wwps-tile-pages    { background: linear-gradient(135deg, #3182ce 0%, #2b6cb0 100%); }
    </style>
    <?php endif; ?>

    <div class="wwps-filter-bar">
        <form method="get" action="">
            <input type="hidden" name="page" value="wwps-tasks">

            <select name="project" onchange="this.form.submit()">
                <?php foreach ( $projects as $p ) : ?>
                    <option value="<?php echo (int) $p->id; ?>" <?php selected( $p->id, $project_id ); ?>><?php echo esc_html( $p->name ); ?></option>
                <?php endforeach; ?>
            </select>

            <select name="status" onchange="this.form.submit()">
                <option value="all"       <?php selected( $status, 'all' ); ?>>All Statuses</option>
                <option value="open"      <?php selected( $status, 'open' ); ?>>Open</option>
                <option value="completed" <?php selected( $status, 'completed' ); ?>>Completed</option>
            </select>

            <select name="priority" onchange="this.form.submit()">
                <option value="all"      <?php selected( $priority, 'all' ); ?>>All Priorities</option>
                <option value="critical" <?php selected( $priority, 'critical' ); ?>>Critical</option>
                <option value="hot"      <?php selected( $priority, 'hot' ); ?>>Hot</option>
                <option value="warm"     <?php selected( $priority, 'warm' ); ?>>Warm</option>
                <option value="cold"     <?php selected( $priority, 'cold' ); ?>>Cold</option>
            </select>

            <div class="wwps-view-toggle">
                <a href="?page=wwps-tasks&project=<?php echo $project_id; ?>&status=<?php echo $status; ?>&priority=<?php echo $priority; ?>&view=list" class="button <?php echo $view === 'list' ? 'button-primary' : ''; ?>">&#8801; List</a>
                <a href="?page=wwps-tasks&project=<?php echo $project_id; ?>&status=<?php echo $status; ?>&priority=<?php echo $priority; ?>&view=kanban" class="button <?php echo $view === 'kanban' ? 'button-primary' : ''; ?>">&#8862; Kanban</a>
            </div>
        </form>

        <?php if ( $project ) : ?>
        <div class="wwps-token-actions">
            <a href="<?php echo esc_url( WWPS_Tokens::get_review_url( $project ) ); ?>" target="_blank" class="button">Open Review Mode &rarr;</a>
            <button class="button wwps-copy-btn" data-copy="<?php echo esc_attr( WWPS_Tokens::get_proof_url( $project ) ); ?>">Copy Proof URL</button>
        </div>
        <?php endif; ?>
    </div>

    <?php if ( empty( $tasks ) ) : ?>
        <div class="wwps-empty-state">
            <span class="dashicons dashicons-yes-alt" style="font-size:48px;color:#38a169;"></span>
            <p>No tasks found for the current filters.</p>
        </div>
    <?php elseif ( $view === 'kanban' ) : ?>

    <?php
        $by_priority = array( 'critical' => array(), 'hot' => array(), 'warm' => array(), 'cold' => array() );
        foreach ( $tasks as $t ) {
            $by_priority[ $t->priority ][] = $t;
        }
    ?>
    <div class="wwps-kanban">
        <?php foreach ( $by_priority as $pri => $ptasks ) : ?>
        <div class="wwps-kanban-col">
            <div class="wwps-kanban-header" style="border-top:3px solid <?php echo WWPS_Tasks::priority_color( $pri ); ?>;">
                <?php echo WWPS_Tasks::priority_badge( $pri ); ?> <span class="wwps-count"><?php echo count( $ptasks ); ?></span>
            </div>
            <?php foreach ( $ptasks as $t ) : ?>
            <div class="wwps-kanban-card">
                <div class="wwps-card-ticket"><code><?php echo esc_html( $t->ticket_id ); ?></code></div>
                <div class="wwps-card-page"><?php echo esc_html( $t->page_title ? $t->page_title : parse_url( $t->page_url, PHP_URL_PATH ) ); ?></div>
                <div class="wwps-card-comment"><?php echo esc_html( mb_substr( $t->comment, 0, 80 ) ); ?>&hellip;</div>
                <div class="wwps-card-footer">
                    <span class="wwps-muted"><?php echo esc_html( $t->author_name ); ?></span>
                    <a href="?page=wwps-tasks&project=<?php echo $project_id; ?>&task=<?php echo (int) $t->id; ?>" class="button button-small">Detail</a>
                    <?php if ( $t->status === 'open' ) : ?>
                        <button class="button button-small wwps-complete-btn" data-task="<?php echo (int) $t->id; ?>">&#10003;</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if ( empty( $ptasks ) ) : ?><p class="wwps-muted" style="padding:12px;">No tasks</p><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <?php else : ?>

    <table class="wp-list-table widefat fixed striped wwps-table">
        <thead>
            <tr>
                <th width="110">Ticket</th>
                <th width="80">Priority</th>
                <th>Comment</th>
                <th>Page</th>
                <th width="120">From</th>
                <th width="90">Status</th>
                <th width="130">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $tasks as $t ) : ?>
            <tr class="wwps-task-row <?php echo esc_attr( $t->status ); ?>">
                <td><code><?php echo esc_html( $t->ticket_id ); ?></code></td>
                <td><?php echo WWPS_Tasks::priority_badge( $t->priority ); ?></td>
                <td>
                    <strong><?php echo esc_html( mb_substr( $t->comment, 0, 100 ) ); ?><?php echo mb_strlen( $t->comment ) > 100 ? '&hellip;' : ''; ?></strong>
                    <div class="wwps-element-hint"><?php echo esc_html( $t->element_tag ); ?><?php echo $t->element_text_before ? ' &mdash; "...' . esc_html( $t->element_text_before ) . '..."' : ''; ?></div>
                    <?php if ( ! empty( $t->image_url ) ) : ?>
                    <div style="margin-top:4px;">
                        <a href="#" onclick="wwpsOpenImg('<?php echo esc_js( $t->image_url ); ?>');return false;"
                           style="font-size:11px;color:#A836BE;text-decoration:none;font-weight:600;">
                            &#128248; View Attached Image
                        </a>
                    </div>
                    <?php endif; ?>
                </td>
                <td><a href="<?php echo esc_url( $t->page_url ); ?>" target="_blank"><?php echo esc_html( $t->page_title ? $t->page_title : parse_url( $t->page_url, PHP_URL_PATH ) ); ?></a></td>
                <td><?php echo esc_html( $t->author_name ); ?></td>
                <td><span class="wwps-status-badge <?php echo esc_attr( $t->status ); ?>"><?php echo ucfirst( $t->status ); ?></span></td>
                <td>
                    <a href="?page=wwps-tasks&project=<?php echo $project_id; ?>&task=<?php echo (int) $t->id; ?>" class="button button-small">Detail</a>
                    <?php if ( $t->status === 'open' ) : ?>
                        <button class="button button-small wwps-complete-btn" data-task="<?php echo (int) $t->id; ?>">&#10003; Done</button>
                    <?php else : ?>
                        <button class="button button-small wwps-reopen-btn" data-task="<?php echo (int) $t->id; ?>">&#8635;</button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
<?php endif; ?>
</div>

<!-- Image modal -->
<div id="wwps-img-modal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.85);z-index:999999;align-items:center;justify-content:center;flex-direction:column;gap:16px;" onclick="if(event.target===this)this.style.display='none';">
    <div style="position:relative;">
        <img id="wwps-img-modal-img" src="" alt="Attached image" style="max-width:90vw;max-height:80vh;border-radius:6px;display:block;box-shadow:0 8px 40px rgba(0,0,0,.6);">
        <button onclick="document.getElementById('wwps-img-modal').style.display='none';"
                style="position:absolute;top:-14px;right:-14px;background:#fff;border:none;border-radius:50%;width:30px;height:30px;font-size:20px;line-height:1;cursor:pointer;font-weight:bold;box-shadow:0 2px 8px rgba(0,0,0,.3);">&times;</button>
    </div>
    <a id="wwps-img-modal-link" href="#" target="_blank" rel="noopener" style="color:#fff;font-size:13px;opacity:.8;text-decoration:underline;">Open full size &#8599;</a>
</div>
<script>
function wwpsOpenImg(url) {
    var modal = document.getElementById('wwps-img-modal');
    document.getElementById('wwps-img-modal-img').src = url;
    document.getElementById('wwps-img-modal-link').href = url;
    modal.style.display = 'flex';
}
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') { document.getElementById('wwps-img-modal').style.display = 'none'; }
});

// Clarifying question
(function($){
    $(document).on('click', '.wwps-clarify-btn', function(){
        var $btn      = $(this);
        var taskId    = $btn.data('task');
        var question  = $.trim($('#wwps-clarify-body').val());
        var $msg      = $('#wwps-clarify-msg');
        if (!question) { $msg.text('Please enter a question.').css('color','#b00'); return; }
        $btn.prop('disabled', true).text('Sending…');
        $.post(wwpsAdmin.ajaxUrl, {
            action:   'wwps_send_clarifying_question',
            nonce:    wwpsAdmin.nonce,
            task_id:  taskId,
            question: question
        }, function(res){
            if (res.success) {
                $msg.text(res.data.message).css('color','green');
                $('#wwps-clarify-body').val('');
                $btn.text('✉ Send Question').prop('disabled', false);
            } else {
                $msg.text(res.data).css('color','#b00');
                $btn.text('✉ Send Question').prop('disabled', false);
            }
        });
    });
})(jQuery);
</script>
