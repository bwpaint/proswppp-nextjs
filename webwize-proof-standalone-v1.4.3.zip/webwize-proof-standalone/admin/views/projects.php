<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap wwps-wrap">
    <h1 class="wp-heading-inline">WebWize Proof &mdash; Projects</h1>
    <button class="page-title-action wwps-btn-primary" id="wwps-new-project-btn">+ New Project</button>
    <hr class="wp-header-end">

    <!-- New Project Modal -->
    <div id="wwps-new-project-modal" class="wwps-modal" style="display:none;">
        <div class="wwps-modal-inner">
            <h2>Create New Project</h2>
            <table class="form-table">
                <tr><th>Project Name</th><td><input type="text" id="np-name" class="regular-text" placeholder="ProSWPPP Dev"></td></tr>
                <tr><th>Client Name</th><td><input type="text" id="np-client" class="regular-text" placeholder="ProSWPPP"></td></tr>
                <tr><th>Client Emails</th><td><input type="text" id="np-emails" class="regular-text" placeholder="client@example.com"><p class="description">Comma-separated. Receive task submitted notifications.</p></td></tr>
                <tr><th>Support Email</th><td><input type="email" id="np-support" class="regular-text" value="<?php echo esc_attr( get_option('admin_email') ); ?>"><p class="description">WebWize team receives all notifications here.</p></td></tr>
            </table>
            <div class="wwps-modal-footer">
                <button class="button button-primary" id="wwps-create-project-submit">Create Project</button>
                <button class="button wwps-modal-close">Cancel</button>
            </div>
        </div>
    </div>

    <?php if ( empty( $projects ) ) : ?>
        <div class="wwps-empty-state">
            <span class="dashicons dashicons-visibility" style="font-size:48px;color:#e94560;"></span>
            <p>No projects yet. Create your first project above.</p>
        </div>
    <?php else : ?>
    <table class="wp-list-table widefat fixed striped wwps-table">
        <thead>
            <tr>
                <th>Project</th>
                <th>Client</th>
                <th>Open Tasks</th>
                <th>Completed</th>
                <th>Pages Approved</th>
                <th>Proof URL</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $projects as $project ) :
            $proof_url  = WWPS_Tokens::get_proof_url( $project );
            $review_url = WWPS_Tokens::get_review_url( $project );
        ?>
            <tr>
                <td><strong><?php echo esc_html( $project->name ); ?></strong></td>
                <td><?php echo esc_html( $project->client_name ); ?></td>
                <td><span class="wwps-count open"><?php echo (int) $project->tasks_open; ?></span></td>
                <td><span class="wwps-count done"><?php echo (int) $project->tasks_completed; ?></span></td>
                <td><span class="wwps-count pages"><?php echo (int) $project->pages_approved; ?></span></td>
                <td>
                    <button class="button button-small wwps-copy-btn" data-copy="<?php echo esc_attr( $proof_url ); ?>">Copy Proof URL</button>
                    <button class="button button-small wwps-copy-btn" data-copy="<?php echo esc_attr( $review_url ); ?>">Copy Review URL</button>
                </td>
                <td>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wwps-tasks&project=' . $project->id ) ); ?>" class="button button-small">View Tasks</a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wwps-settings&project=' . $project->id ) ); ?>" class="button button-small">Settings</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
