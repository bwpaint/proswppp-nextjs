<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap wwps-wrap">
<h1>People &amp; Teams</h1>

<div style="display:flex;gap:32px;align-items:flex-start;flex-wrap:wrap;">

    <!-- ============================================================
         CONTACTS column
    ============================================================ -->
    <div style="flex:1;min-width:320px;max-width:480px;">
        <h2 style="margin-top:0;">Contacts</h2>

        <div id="wwps-contact-form" style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:18px 20px;margin-bottom:20px;">
            <h3 style="margin-top:0;font-size:14px;color:#555;" id="wwps-contact-form-title">Add New Contact</h3>
            <input type="hidden" id="wwps-contact-id" value="0">
            <table style="width:100%;">
                <tr>
                    <td style="padding:4px 0;"><label style="font-size:13px;font-weight:600;">Name</label></td>
                    <td style="padding:4px 0 4px 8px;"><input type="text" id="wwps-contact-name" style="width:100%;" placeholder="Jane Smith"></td>
                </tr>
                <tr>
                    <td style="padding:4px 0;"><label style="font-size:13px;font-weight:600;">Email</label></td>
                    <td style="padding:4px 0 4px 8px;"><input type="email" id="wwps-contact-email" style="width:100%;" placeholder="jane@example.com"></td>
                </tr>
            </table>
            <div style="margin-top:12px;display:flex;gap:8px;">
                <button class="button button-primary" id="wwps-save-contact-btn">Save Contact</button>
                <button class="button" id="wwps-cancel-contact-btn" style="display:none;">Cancel</button>
            </div>
            <p id="wwps-contact-msg" style="margin:8px 0 0;font-size:12px;"></p>
        </div>

        <table class="widefat striped" id="wwps-contacts-table">
            <thead><tr>
                <th>Name</th>
                <th>Email</th>
                <th style="width:80px;text-align:right;">Actions</th>
            </tr></thead>
            <tbody id="wwps-contacts-tbody">
            <?php if ( empty( $contacts ) ) : ?>
                <tr id="wwps-no-contacts"><td colspan="3" style="color:#999;font-style:italic;">No contacts yet.</td></tr>
            <?php else : ?>
                <?php foreach ( $contacts as $c ) : ?>
                <tr id="wwps-contact-row-<?php echo (int) $c->id; ?>">
                    <td><?php echo esc_html( $c->name ); ?></td>
                    <td><?php echo esc_html( $c->email ); ?></td>
                    <td style="text-align:right;white-space:nowrap;">
                        <a href="#" class="wwps-edit-contact" data-id="<?php echo (int) $c->id; ?>" data-name="<?php echo esc_attr( $c->name ); ?>" data-email="<?php echo esc_attr( $c->email ); ?>" style="color:#0073aa;margin-right:6px;">Edit</a>
                        <a href="#" class="wwps-delete-contact" data-id="<?php echo (int) $c->id; ?>" style="color:#b00;">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- ============================================================
         TEAMS column
    ============================================================ -->
    <div style="flex:2;min-width:400px;">
        <h2 style="margin-top:0;">Teams</h2>
        <p style="color:#666;font-size:13px;">Add contacts to teams. The Webmaster team name is locked; others can be renamed.</p>

        <?php foreach ( $teams as $team ) :
            $members = WWPS_Contacts::get_for_team( $team->id );
            // Contacts NOT already in this team
            $member_ids = array_map( function($m){ return (int) $m->id; }, $members );
            $available  = array_filter( $contacts, function($c) use ($member_ids){ return ! in_array( (int) $c->id, $member_ids, true ); } );
        ?>
        <div class="wwps-team-card" data-team-id="<?php echo (int) $team->id; ?>" style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px 20px;margin-bottom:18px;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                <?php if ( $team->is_name_locked ) : ?>
                    <h3 style="margin:0;font-size:15px;"><?php echo esc_html( $team->name ); ?> <span style="font-size:11px;color:#999;font-weight:normal;">(name locked)</span></h3>
                <?php else : ?>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <h3 class="wwps-team-name-display" style="margin:0;font-size:15px;"><?php echo esc_html( $team->name ); ?></h3>
                        <a href="#" class="wwps-rename-team-btn" data-team-id="<?php echo (int) $team->id; ?>" style="font-size:12px;color:#0073aa;">Rename</a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Rename inline form (hidden by default) -->
            <?php if ( ! $team->is_name_locked ) : ?>
            <div class="wwps-rename-form" data-team-id="<?php echo (int) $team->id; ?>" style="display:none;margin-bottom:12px;">
                <input type="text" class="wwps-rename-input" value="<?php echo esc_attr( $team->name ); ?>" style="width:220px;">
                <button class="button button-small wwps-rename-save" data-team-id="<?php echo (int) $team->id; ?>">Save</button>
                <button class="button button-small wwps-rename-cancel">Cancel</button>
            </div>
            <?php endif; ?>

            <!-- Member list -->
            <ul class="wwps-member-list" data-team-id="<?php echo (int) $team->id; ?>" style="margin:0 0 12px;padding:0;list-style:none;">
                <?php if ( empty( $members ) ) : ?>
                <li class="wwps-member-empty" style="color:#999;font-style:italic;font-size:13px;">No members yet.</li>
                <?php else : ?>
                    <?php foreach ( $members as $m ) : ?>
                    <li style="display:flex;align-items:center;justify-content:space-between;padding:4px 0;border-bottom:1px solid #f0f0f0;font-size:13px;" data-contact-id="<?php echo (int) $m->id; ?>">
                        <span><?php echo esc_html( $m->name ); ?> &lt;<?php echo esc_html( $m->email ); ?>&gt;</span>
                        <a href="#" class="wwps-remove-member" data-team-id="<?php echo (int) $team->id; ?>" data-contact-id="<?php echo (int) $m->id; ?>" style="color:#b00;font-size:12px;">Remove</a>
                    </li>
                    <?php endforeach; ?>
                <?php endif; ?>
            </ul>

            <!-- Add member row -->
            <div style="display:flex;align-items:center;gap:8px;">
                <select class="wwps-add-member-select" data-team-id="<?php echo (int) $team->id; ?>" style="flex:1;">
                    <option value="">— Select a contact to add —</option>
                    <?php foreach ( $available as $av ) : ?>
                    <option value="<?php echo (int) $av->id; ?>" data-name="<?php echo esc_attr( $av->name ); ?>" data-email="<?php echo esc_attr( $av->email ); ?>">
                        <?php echo esc_html( $av->name ); ?> &lt;<?php echo esc_html( $av->email ); ?>&gt;
                    </option>
                    <?php endforeach; ?>
                </select>
                <button class="button wwps-add-member-btn" data-team-id="<?php echo (int) $team->id; ?>">+ Add</button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

</div><!-- /flex -->
</div><!-- /wrap -->

<script>
jQuery(document).ready(function($){
    var nonce   = wwpsAdmin.nonce;
    var ajaxUrl = wwpsAdmin.ajaxUrl;

    // ---- Contacts ----

    function resetContactForm() {
        $('#wwps-contact-id').val('0');
        $('#wwps-contact-name').val('');
        $('#wwps-contact-email').val('');
        $('#wwps-contact-form-title').text('Add New Contact');
        $('#wwps-save-contact-btn').text('Save Contact');
        $('#wwps-cancel-contact-btn').hide();
        $('#wwps-contact-msg').text('');
    }

    $('#wwps-save-contact-btn').on('click', function(){
        var id    = $('#wwps-contact-id').val();
        var name  = $.trim($('#wwps-contact-name').val());
        var email = $.trim($('#wwps-contact-email').val());
        if (!name || !email) { $('#wwps-contact-msg').text('Name and email required.').css('color','#b00'); return; }
        $.post(ajaxUrl, { action:'wwps_save_contact', nonce:nonce, id:id, name:name, email:email }, function(res){
            if (!res.success) { $('#wwps-contact-msg').text(res.data).css('color','#b00'); return; }
            $('#wwps-contact-msg').text('Saved!').css('color','green');
            var cid = res.data.id;
            // Update or add row
            var rowHtml = '<tr id="wwps-contact-row-'+cid+'">'
                + '<td>'+$('<span>').text(res.data.name).html()+'</td>'
                + '<td>'+$('<span>').text(res.data.email).html()+'</td>'
                + '<td style="text-align:right;white-space:nowrap;">'
                + '<a href="#" class="wwps-edit-contact" data-id="'+cid+'" data-name="'+$('<span>').text(res.data.name).html()+'" data-email="'+$('<span>').text(res.data.email).html()+'" style="color:#0073aa;margin-right:6px;">Edit</a>'
                + '<a href="#" class="wwps-delete-contact" data-id="'+cid+'" style="color:#b00;">Delete</a>'
                + '</td></tr>';
            if (id && id !== '0') {
                $('#wwps-contact-row-'+cid).replaceWith(rowHtml);
            } else {
                $('#wwps-no-contacts').remove();
                $('#wwps-contacts-tbody').append(rowHtml);
                // Also add to all "available" dropdowns
                var optHtml = '<option value="'+cid+'" data-name="'+$('<span>').text(res.data.name).html()+'" data-email="'+$('<span>').text(res.data.email).html()+'">'+$('<span>').text(res.data.name).html()+' &lt;'+$('<span>').text(res.data.email).html()+'&gt;</option>';
                $('.wwps-add-member-select').each(function(){ $(this).append(optHtml); });
            }
            resetContactForm();
        });
    });

    $('#wwps-cancel-contact-btn').on('click', function(e){ e.preventDefault(); resetContactForm(); });

    $(document).on('click', '.wwps-edit-contact', function(e){
        e.preventDefault();
        var $a = $(this);
        $('#wwps-contact-id').val($a.data('id'));
        $('#wwps-contact-name').val($a.data('name'));
        $('#wwps-contact-email').val($a.data('email'));
        $('#wwps-contact-form-title').text('Edit Contact');
        $('#wwps-save-contact-btn').text('Update Contact');
        $('#wwps-cancel-contact-btn').show();
        $('#wwps-contact-msg').text('');
        $('html,body').animate({scrollTop: $('#wwps-contact-form').offset().top - 40}, 200);
    });

    $(document).on('click', '.wwps-delete-contact', function(e){
        e.preventDefault();
        if (!confirm('Delete this contact? They will be removed from all teams.')) return;
        var id = $(this).data('id');
        $.post(ajaxUrl, { action:'wwps_delete_contact', nonce:nonce, id:id }, function(res){
            if (res.success) {
                $('#wwps-contact-row-'+id).remove();
                // Remove from team member lists
                $('[data-contact-id="'+id+'"]').remove();
                // Remove from add-member selects
                $('.wwps-add-member-select option[value="'+id+'"]').remove();
            }
        });
    });

    // ---- Teams: rename ----

    $(document).on('click', '.wwps-rename-team-btn', function(e){
        e.preventDefault();
        var tid = $(this).data('team-id');
        $('.wwps-rename-form[data-team-id="'+tid+'"]').show();
        $(this).hide();
    });

    $(document).on('click', '.wwps-rename-cancel', function(){
        $(this).closest('.wwps-rename-form').hide();
        $(this).closest('.wwps-team-card').find('.wwps-rename-team-btn').show();
    });

    $(document).on('click', '.wwps-rename-save', function(){
        var tid  = $(this).data('team-id');
        var name = $.trim($(this).closest('.wwps-rename-form').find('.wwps-rename-input').val());
        if (!name) return;
        var $btn = $(this);
        $.post(ajaxUrl, { action:'wwps_rename_team', nonce:nonce, team_id:tid, name:name }, function(res){
            if (!res.success) { alert(res.data); return; }
            $btn.closest('.wwps-team-card').find('.wwps-team-name-display').text(name);
            $btn.closest('.wwps-rename-form').hide();
            $btn.closest('.wwps-team-card').find('.wwps-rename-team-btn').show();
        });
    });

    // ---- Teams: add member ----

    $(document).on('click', '.wwps-add-member-btn', function(){
        var $btn    = $(this);
        var tid     = $btn.data('team-id');
        var $select = $('.wwps-add-member-select[data-team-id="'+tid+'"]');
        var cid     = $select.val();
        if (!cid) return;
        var $opt = $select.find('option[value="'+cid+'"]');
        var name  = $opt.data('name');
        var email = $opt.data('email');
        $.post(ajaxUrl, { action:'wwps_add_team_member', nonce:nonce, team_id:tid, contact_id:cid }, function(res){
            if (!res.success) return;
            var $list = $('.wwps-member-list[data-team-id="'+tid+'"]');
            $list.find('.wwps-member-empty').remove();
            $list.append('<li style="display:flex;align-items:center;justify-content:space-between;padding:4px 0;border-bottom:1px solid #f0f0f0;font-size:13px;" data-contact-id="'+cid+'">'
                + '<span>'+$('<span>').text(name).html()+' &lt;'+$('<span>').text(email).html()+'&gt;</span>'
                + '<a href="#" class="wwps-remove-member" data-team-id="'+tid+'" data-contact-id="'+cid+'" style="color:#b00;font-size:12px;">Remove</a>'
                + '</li>');
            $opt.remove(); // remove from the available dropdown
        });
    });

    // ---- Teams: remove member ----

    $(document).on('click', '.wwps-remove-member', function(e){
        e.preventDefault();
        var $a  = $(this);
        var tid = $a.data('team-id');
        var cid = $a.data('contact-id');
        $.post(ajaxUrl, { action:'wwps_remove_team_member', nonce:nonce, team_id:tid, contact_id:cid }, function(res){
            if (!res.success) return;
            var $row  = $a.closest('li');
            var name  = $.trim($row.find('span').first().text());
            // Put back in the "available" select for this team
            var $select = $('.wwps-add-member-select[data-team-id="'+tid+'"]');
            $select.append('<option value="'+cid+'" data-name="'+$('<span>').text(name).html()+'" data-email="">'+$('<span>').text(name).html()+'</option>');
            $row.remove();
            if ( $('.wwps-member-list[data-team-id="'+tid+'"] li').length === 0 ) {
                $('.wwps-member-list[data-team-id="'+tid+'"]').append('<li class="wwps-member-empty" style="color:#999;font-style:italic;font-size:13px;">No members yet.</li>');
            }
        });
    });

});
</script>
