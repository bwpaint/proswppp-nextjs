<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap wwps-wrap">
<h1>Notification Setup</h1>
<p style="color:#555;">For each event, choose which teams receive an email notification. Toggle the switch to pause an event entirely.</p>

<table class="widefat" style="max-width:760px;border-collapse:separate;border-spacing:0;">
<thead>
<tr style="background:#f1f1f1;">
    <th style="width:200px;padding:10px 14px;">Event</th>
    <th style="width:80px;padding:10px 14px;text-align:center;">Enabled</th>
    <th style="padding:10px 14px;">Notified Teams</th>
</tr>
</thead>
<tbody>
<?php foreach ( $labels as $event_type => $label ) :
    $row     = isset( $settings[ $event_type ] ) ? $settings[ $event_type ] : null;
    $enabled = $row ? (bool) $row->enabled : true;
    $ev_teams = isset( $assigned[ $event_type ] ) ? $assigned[ $event_type ] : array();
    $assigned_ids = array_map( function($t){ return (int) $t->id; }, $ev_teams );
    $available    = array_filter( $teams, function($t) use ($assigned_ids){ return ! in_array( (int) $t->id, $assigned_ids, true ); } );
?>
<tr class="wwps-notif-row" data-event="<?php echo esc_attr( $event_type ); ?>" style="<?php echo $enabled ? '' : 'opacity:0.55;'; ?>">
    <td style="padding:12px 14px;vertical-align:top;font-weight:600;font-size:13px;"><?php echo esc_html( $label ); ?></td>
    <td style="padding:12px 14px;text-align:center;vertical-align:top;">
        <label class="wwps-toggle-label" title="<?php echo $enabled ? 'Click to disable' : 'Click to enable'; ?>">
            <input type="checkbox" class="wwps-notif-toggle" data-event="<?php echo esc_attr( $event_type ); ?>" <?php checked( $enabled ); ?> style="display:none;">
            <span class="wwps-toggle-track" style="display:inline-block;width:40px;height:22px;border-radius:11px;background:<?php echo $enabled ? '#4caf50' : '#ccc'; ?>;position:relative;cursor:pointer;transition:background .2s;">
                <span class="wwps-toggle-thumb" style="position:absolute;top:3px;left:<?php echo $enabled ? '20px' : '3px'; ?>;width:16px;height:16px;border-radius:50%;background:#fff;transition:left .2s;box-shadow:0 1px 3px rgba(0,0,0,.3);"></span>
            </span>
        </label>
    </td>
    <td style="padding:12px 14px;vertical-align:top;">
        <ul class="wwps-notif-team-list" data-event="<?php echo esc_attr( $event_type ); ?>" style="margin:0 0 10px;padding:0;list-style:none;">
            <?php if ( empty( $ev_teams ) ) : ?>
            <li class="wwps-notif-no-teams" style="color:#999;font-style:italic;font-size:12px;">No teams assigned — no notifications will be sent.</li>
            <?php else : foreach ( $ev_teams as $et ) :
                $is_locked_team = (int) $et->is_name_locked === 1;
            ?>
            <li style="display:inline-flex;align-items:center;gap:6px;background:<?php echo $is_locked_team ? '#fde8c8' : '#e8f0fe'; ?>;border-radius:12px;padding:3px 10px;margin:0 4px 4px 0;font-size:12px;font-weight:600;<?php echo $is_locked_team ? 'border:1px solid #f6ad55;' : ''; ?>" data-team-id="<?php echo (int) $et->id; ?>" data-locked="<?php echo $is_locked_team ? '1' : '0'; ?>">
                <?php echo esc_html( $et->name ); ?>
                <?php if ( $is_locked_team ) : ?>
                    <?php if ( $is_admin ) : ?>
                        <a href="#" class="wwps-notif-remove-team" data-event="<?php echo esc_attr( $event_type ); ?>" data-team-id="<?php echo (int) $et->id; ?>" style="color:#b00;text-decoration:none;font-size:14px;line-height:1;" title="Remove Webmaster team (Admin only)">&times;</a>
                    <?php else : ?>
                        <span title="Only WordPress administrators can remove the Webmaster team from notifications" style="cursor:not-allowed;font-size:12px;opacity:.55;">&#128274;</span>
                    <?php endif; ?>
                <?php else : ?>
                    <a href="#" class="wwps-notif-remove-team" data-event="<?php echo esc_attr( $event_type ); ?>" data-team-id="<?php echo (int) $et->id; ?>" style="color:#b00;text-decoration:none;font-size:14px;line-height:1;" title="Remove">&times;</a>
                <?php endif; ?>
            </li>
            <?php endforeach; endif; ?>
        </ul>
        <div style="display:flex;gap:8px;align-items:center;">
            <select class="wwps-notif-add-select" data-event="<?php echo esc_attr( $event_type ); ?>" style="min-width:160px;">
                <option value="">— Add team —</option>
                <?php foreach ( $available as $at ) : ?>
                <option value="<?php echo (int) $at->id; ?>"><?php echo esc_html( $at->name ); ?></option>
                <?php endforeach; ?>
            </select>
            <button class="button button-small wwps-notif-add-btn" data-event="<?php echo esc_attr( $event_type ); ?>">+ Add</button>
        </div>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<p style="margin-top:18px;font-size:12px;color:#888;">Changes are saved immediately — no Submit button needed. <span style="color:#c8821a;">&#128274; Webmaster team assignments can only be removed by WordPress administrators.</span></p>

<script>
jQuery(document).ready(function($){
    var nonce   = wwpsAdmin.nonce;
    var ajaxUrl = wwpsAdmin.ajaxUrl;

    // ---- Toggle on/off ----
    $(document).on('change', '.wwps-notif-toggle', function(){
        var $cb      = $(this);
        var event    = $cb.data('event');
        var enabled  = $cb.is(':checked') ? 1 : 0;
        var $track   = $cb.siblings('.wwps-toggle-track');
        var $thumb   = $track.find('.wwps-toggle-thumb');
        var $row     = $cb.closest('.wwps-notif-row');

        $track.css('background', enabled ? '#4caf50' : '#ccc');
        $thumb.css('left', enabled ? '20px' : '3px');
        $row.css('opacity', enabled ? '1' : '0.55');

        $.post(ajaxUrl, { action:'wwps_save_notif_settings', nonce:nonce, sub_action:'toggle', event_type:event, enabled:enabled });
    });

    // Click on track toggles the hidden checkbox
    $(document).on('click', '.wwps-toggle-track', function(){
        $(this).siblings('input[type=checkbox]').prop('checked', function(i, v){ return !v; }).trigger('change');
    });

    // ---- Add team ----
    $(document).on('click', '.wwps-notif-add-btn', function(){
        var event   = $(this).data('event');
        var $select = $('.wwps-notif-add-select[data-event="'+event+'"]');
        var tid     = $select.val();
        if (!tid) return;
        var $opt    = $select.find('option[value="'+tid+'"]');
        var name    = $opt.text();
        $.post(ajaxUrl, { action:'wwps_save_notif_settings', nonce:nonce, sub_action:'add_team', event_type:event, team_id:tid }, function(res){
            if (!res.success) return;
            var $list = $('.wwps-notif-team-list[data-event="'+event+'"]');
            $list.find('.wwps-notif-no-teams').remove();
            // Add the chip — no locked styling for newly added teams (Webmaster already locked on page load)
            $list.append('<li style="display:inline-flex;align-items:center;gap:6px;background:#e8f0fe;border-radius:12px;padding:3px 10px;margin:0 4px 4px 0;font-size:12px;font-weight:600;" data-team-id="'+tid+'" data-locked="0">'
                + $('<span>').text(name).html()
                + ' <a href="#" class="wwps-notif-remove-team" data-event="'+event+'" data-team-id="'+tid+'" style="color:#b00;text-decoration:none;font-size:14px;line-height:1;" title="Remove">&times;</a>'
                + '</li>');
            $opt.remove();
            $select.val('');
        });
    });

    // ---- Remove team ----
    $(document).on('click', '.wwps-notif-remove-team', function(e){
        e.preventDefault();
        var $link = $(this);
        var event = $link.data('event');
        var tid   = $link.data('team-id');
        var name  = $.trim($link.closest('li').clone().children().remove().end().text());
        $.post(ajaxUrl, { action:'wwps_save_notif_settings', nonce:nonce, sub_action:'remove_team', event_type:event, team_id:tid }, function(res){
            if (!res.success) {
                alert(res.data || 'Unable to remove team.');
                return;
            }
            var $list = $('.wwps-notif-team-list[data-event="'+event+'"]');
            $list.find('[data-team-id="'+tid+'"]').remove();
            if ( $list.find('li').length === 0 ) {
                $list.append('<li class="wwps-notif-no-teams" style="color:#999;font-style:italic;font-size:12px;">No teams assigned — no notifications will be sent.</li>');
            }
            // Put back in the available dropdown
            $('.wwps-notif-add-select[data-event="'+event+'"]').append('<option value="'+tid+'">'+$('<span>').text(name).html()+'</option>');
        });
    });

});
</script>
</div>
