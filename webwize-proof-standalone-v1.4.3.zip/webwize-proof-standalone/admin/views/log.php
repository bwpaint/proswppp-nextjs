<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap wwps-wrap">
    <h1>WebWize Proof &mdash; Notification Log</h1>
    <?php if ( empty( $log ) ) : ?>
        <div class="wwps-empty-state">
            <p>No notifications sent yet.</p>
        </div>
    <?php else : ?>
    <table class="wp-list-table widefat fixed striped wwps-table">
        <thead>
            <tr>
                <th width="140">Date</th>
                <th width="100">Ticket</th>
                <th width="120">Project</th>
                <th width="80">Template</th>
                <th>Recipient</th>
                <th>Subject</th>
                <th width="70">Status</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $log as $entry ) : ?>
            <tr class="<?php echo $entry->status === 'failed' ? 'wwps-row-error' : ''; ?>">
                <td><?php echo esc_html( $entry->created_at ); ?></td>
                <td><code><?php echo esc_html( $entry->ticket_id ); ?></code></td>
                <td><?php echo esc_html( $entry->project_name ); ?></td>
                <td><span class="wwps-template-badge"><?php echo esc_html( $entry->template ); ?></span></td>
                <td><?php echo esc_html( $entry->recipient_email ); ?></td>
                <td><?php echo esc_html( $entry->subject ); ?></td>
                <td><span class="wwps-status-badge <?php echo $entry->status === 'sent' ? 'completed' : 'open'; ?>"><?php echo esc_html( $entry->status ); ?></span></td>
            </tr>
            <?php if ( $entry->error ) : ?>
            <tr>
                <td colspan="7" style="color:#e53e3e;padding-left:20px;font-size:12px;"><?php echo esc_html( $entry->error ); ?></td>
            </tr>
            <?php endif; ?>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
