<?php
/**
 * Plugin Name: WebWize Proof (Standalone)
 * Plugin URI:  https://webwize.com
 * Description: Visual client proofing and feedback tool. Clients leave pinned comments on any page element; your team reviews, manages, and completes tasks from the WordPress dashboard.
 * Version: 1.4.3
 * Author:      WebWize
 * Author URI:  https://webwize.com
 * Text Domain: webwize-proof
 */

defined( 'ABSPATH' ) || exit;

define( 'WWPS_VERSION',    '1.4.3' );
define( 'WWPS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WWPS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WWPS_PLUGIN_FILE', __FILE__ );

require_once WWPS_PLUGIN_DIR . 'includes/class-db.php';
require_once WWPS_PLUGIN_DIR . 'includes/class-tokens.php';
require_once WWPS_PLUGIN_DIR . 'includes/class-tasks.php';
require_once WWPS_PLUGIN_DIR . 'includes/class-contacts.php';
require_once WWPS_PLUGIN_DIR . 'includes/class-teams.php';
require_once WWPS_PLUGIN_DIR . 'includes/class-notification-settings.php';
require_once WWPS_PLUGIN_DIR . 'includes/class-notifications.php';
require_once WWPS_PLUGIN_DIR . 'includes/class-rest-api.php';
require_once WWPS_PLUGIN_DIR . 'includes/class-snippet.php';
require_once WWPS_PLUGIN_DIR . 'admin/class-admin.php';

register_activation_hook( __FILE__, array( 'WWPS_DB', 'install' ) );
register_deactivation_hook( __FILE__, function() {
    wp_clear_scheduled_hook( 'wwps_overdue_digest' );
} );

add_action( 'plugins_loaded', function() {
    if ( get_option( 'wwps_db_version' ) !== WWPS_DB::DB_VERSION ) {
        WWPS_DB::install();
    }
    WWPS_Tokens::init();
    WWPS_Snippet::init();
    WWPS_REST_API::init();
    WWPS_Admin::init();
    WWPS_Notifications::init();
    if ( ! wp_next_scheduled( 'wwps_overdue_digest' ) ) {
        wp_schedule_event( strtotime( 'today 08:00:00' ), 'daily', 'wwps_overdue_digest' );
    }
} );
