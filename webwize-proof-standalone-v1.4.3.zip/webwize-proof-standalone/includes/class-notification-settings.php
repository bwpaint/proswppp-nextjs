<?php
defined( 'ABSPATH' ) || exit;

class WWPS_Notification_Settings {

    /**
     * All four event types with human-readable labels.
     */
    public static function event_labels() {
        return array(
            'task_submitted'  => 'Task Submitted',
            'task_updated'    => 'Task Updated',
            'task_completed'  => 'Task Completed',
            'comment_added'   => 'Comment Added',
        );
    }

    /**
     * Get all notification settings rows, keyed by event_type.
     */
    public static function get_all() {
        global $wpdb;
        $rows    = $wpdb->get_results( "SELECT * FROM " . WWPS_DB::notification_settings_table() );
        $indexed = array();
        foreach ( $rows as $row ) {
            $indexed[ $row->event_type ] = $row;
        }
        return $indexed;
    }

    /**
     * Check whether an event is enabled.
     */
    public static function is_enabled( $event_type ) {
        global $wpdb;
        $val = $wpdb->get_var( $wpdb->prepare(
            "SELECT enabled FROM " . WWPS_DB::notification_settings_table() . " WHERE event_type = %s",
            $event_type
        ) );
        return $val === null ? true : (bool) $val;
    }

    /**
     * Toggle an event on or off.
     */
    public static function set_enabled( $event_type, $enabled ) {
        global $wpdb;
        $table = WWPS_DB::notification_settings_table();
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE event_type = %s", $event_type
        ) );
        if ( $exists ) {
            $wpdb->update( $table, array( 'enabled' => $enabled ? 1 : 0 ), array( 'event_type' => $event_type ) );
        } else {
            $wpdb->insert( $table, array( 'event_type' => sanitize_text_field( $event_type ), 'enabled' => $enabled ? 1 : 0 ) );
        }
    }
}
