<?php
defined( 'ABSPATH' ) || exit;

class WWPS_Tokens {

    public static function init() {}

    public static function get_project_by_proof_token( $token ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM " . WWPS_DB::projects_table() . " WHERE proof_token = %s LIMIT 1", $token )
        );
    }

    public static function get_project_by_review_token( $token ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM " . WWPS_DB::projects_table() . " WHERE review_token = %s LIMIT 1", $token )
        );
    }

    public static function get_project_by_id( $id ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM " . WWPS_DB::projects_table() . " WHERE id = %d LIMIT 1", $id )
        );
    }

    public static function regenerate_proof_token( $project_id ) {
        global $wpdb;
        $token = bin2hex( random_bytes( 32 ) );
        $wpdb->update( WWPS_DB::projects_table(), array( 'proof_token' => $token ), array( 'id' => $project_id ) );
        return $token;
    }

    public static function regenerate_review_token( $project_id ) {
        global $wpdb;
        $token = bin2hex( random_bytes( 32 ) );
        $wpdb->update( WWPS_DB::projects_table(), array( 'review_token' => $token ), array( 'id' => $project_id ) );
        return $token;
    }

    public static function base_url( $project ) {
        return ! empty( $project->frontend_url )
            ? rtrim( $project->frontend_url, '/' ) . '/'
            : home_url( '/' );
    }

    public static function get_proof_url( $project, $page_url = '' ) {
        $base = $page_url ? $page_url : self::base_url( $project );
        if ( $page_url && ! empty( $project->frontend_url ) ) {
            $frontend_host = parse_url( $project->frontend_url, PHP_URL_HOST );
            $page_host     = parse_url( $page_url, PHP_URL_HOST );
            if ( $frontend_host && $page_host && $frontend_host !== $page_host ) {
                $base = str_replace( $page_host, $frontend_host, $page_url );
            }
        }
        return add_query_arg( 'proof', $project->proof_token, $base );
    }

    public static function get_review_url( $project, $page_url = '' ) {
        $base = $page_url ? $page_url : self::base_url( $project );
        if ( $page_url && ! empty( $project->frontend_url ) ) {
            $frontend_host = parse_url( $project->frontend_url, PHP_URL_HOST );
            $page_host     = parse_url( $page_url, PHP_URL_HOST );
            if ( $frontend_host && $page_host && $frontend_host !== $page_host ) {
                $base = str_replace( $page_host, $frontend_host, $page_url );
            }
        }
        return add_query_arg( 'review', $project->review_token, $base );
    }
}
