<?php
defined( 'ABSPATH' ) || exit;

class WWPS_Tasks {

    public static function create( $data ) {
        global $wpdb;
        $ticket_id = WWPS_DB::next_ticket_id();
        $inserted = $wpdb->insert( WWPS_DB::tasks_table(), array(
            'project_id'          => (int) $data['project_id'],
            'ticket_id'           => $ticket_id,
            'page_url'            => isset( $data['page_url'] ) ? sanitize_url( $data['page_url'] ) : '',
            'page_title'          => isset( $data['page_title'] ) ? sanitize_text_field( $data['page_title'] ) : '',
            'element_selector'    => isset( $data['element_selector'] ) ? sanitize_text_field( $data['element_selector'] ) : '',
            'element_tag'         => isset( $data['element_tag'] ) ? sanitize_text_field( $data['element_tag'] ) : '',
            'element_text_before' => isset( $data['element_text_before'] ) ? sanitize_text_field( $data['element_text_before'] ) : '',
            'element_text_after'  => isset( $data['element_text_after'] ) ? sanitize_text_field( $data['element_text_after'] ) : '',
            'scroll_percent'      => isset( $data['scroll_percent'] ) ? (int) $data['scroll_percent'] : 0,
            'viewport_x_percent'  => isset( $data['viewport_x_percent'] ) ? (int) $data['viewport_x_percent'] : 0,
            'viewport_y_percent'  => isset( $data['viewport_y_percent'] ) ? (int) $data['viewport_y_percent'] : 0,
            'device_type'         => isset( $data['device_type'] ) ? sanitize_text_field( $data['device_type'] ) : 'desktop',
            'viewport_width'      => isset( $data['viewport_width'] ) ? (int) $data['viewport_width'] : 0,
            'viewport_height'     => isset( $data['viewport_height'] ) ? (int) $data['viewport_height'] : 0,
            'pixel_ratio'         => isset( $data['pixel_ratio'] ) ? (float) $data['pixel_ratio'] : 1.0,
            'browser'             => isset( $data['browser'] ) ? sanitize_text_field( $data['browser'] ) : '',
            'os'                  => isset( $data['os'] ) ? sanitize_text_field( $data['os'] ) : '',
            'priority'            => ( isset( $data['priority'] ) && in_array( $data['priority'], array( 'critical', 'hot', 'warm', 'cold' ) ) ) ? $data['priority'] : 'warm',
            'author_name'         => isset( $data['author_name'] ) ? sanitize_text_field( $data['author_name'] ) : 'Anonymous',
            'author_email'        => isset( $data['author_email'] ) ? sanitize_email( $data['author_email'] ) : '',
            'comment'             => isset( $data['comment'] ) ? sanitize_textarea_field( $data['comment'] ) : '',
            'image_url'           => isset( $data['image_url'] ) ? esc_url_raw( $data['image_url'] ) : '',
            'status'              => 'open',
        ) );

        if ( ! $inserted ) {
            return false;
        }

        $task_id = $wpdb->insert_id;

        $wpdb->query( $wpdb->prepare(
            "UPDATE " . WWPS_DB::projects_table() . " SET tasks_open = tasks_open + 1 WHERE id = %d",
            $data['project_id']
        ) );

        self::upsert_page(
            (int) $data['project_id'],
            isset( $data['page_url'] ) ? $data['page_url'] : '',
            isset( $data['page_title'] ) ? $data['page_title'] : ''
        );

        self::write_backup( $task_id, $data, $ticket_id );

        return $task_id;
    }

    public static function get( $task_id ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM " . WWPS_DB::tasks_table() . " WHERE id = %d", $task_id )
        );
    }

    public static function get_for_project( $project_id, $filters = array() ) {
        global $wpdb;
        $where = array( $wpdb->prepare( 'project_id = %d', $project_id ) );

        if ( ! empty( $filters['status'] ) && $filters['status'] !== 'all' ) {
            $where[] = $wpdb->prepare( 'status = %s', $filters['status'] );
        }
        if ( ! empty( $filters['priority'] ) && $filters['priority'] !== 'all' ) {
            $where[] = $wpdb->prepare( 'priority = %s', $filters['priority'] );
        }
        if ( ! empty( $filters['page_url'] ) ) {
            $where[] = $wpdb->prepare( 'page_url = %s', $filters['page_url'] );
        }

        $sql = "SELECT * FROM " . WWPS_DB::tasks_table()
             . " WHERE " . implode( ' AND ', $where )
             . " ORDER BY FIELD(priority,'critical','hot','warm','cold'), created_at DESC";

        $results = $wpdb->get_results( $sql );
        return $results ? $results : array();
    }

    public static function get_for_page( $project_id, $page_url ) {
        global $wpdb;
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM " . WWPS_DB::tasks_table()
                . " WHERE project_id = %d AND page_url = %s AND status = 'open' ORDER BY created_at ASC",
                $project_id, $page_url
            )
        );
        return $results ? $results : array();
    }

    public static function complete( $task_id, $completed_by = '' ) {
        global $wpdb;
        $task = self::get( $task_id );
        if ( ! $task ) {
            return false;
        }
        $updated = $wpdb->update( WWPS_DB::tasks_table(), array(
            'status'       => 'completed',
            'completed_by' => $completed_by,
            'completed_at' => current_time( 'mysql' ),
        ), array( 'id' => $task_id ) );

        if ( $updated ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE " . WWPS_DB::projects_table()
                . " SET tasks_open = GREATEST(tasks_open - 1, 0), tasks_completed = tasks_completed + 1"
                . " WHERE id = %d",
                $task->project_id
            ) );
        }
        return (bool) $updated;
    }

    public static function reopen( $task_id ) {
        global $wpdb;
        $task = self::get( $task_id );
        if ( ! $task ) {
            return false;
        }
        $updated = $wpdb->update( WWPS_DB::tasks_table(), array(
            'status'       => 'open',
            'completed_by' => '',
            'completed_at' => null,
        ), array( 'id' => $task_id ) );

        if ( $updated ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE " . WWPS_DB::projects_table()
                . " SET tasks_open = tasks_open + 1, tasks_completed = GREATEST(tasks_completed - 1, 0)"
                . " WHERE id = %d",
                $task->project_id
            ) );
        }
        return (bool) $updated;
    }

    public static function add_comment( $task_id, $data ) {
        global $wpdb;
        $wpdb->insert( WWPS_DB::comments_table(), array(
            'task_id'      => $task_id,
            'author_name'  => isset( $data['author_name'] ) ? sanitize_text_field( $data['author_name'] ) : 'WebWize Team',
            'author_email' => isset( $data['author_email'] ) ? sanitize_email( $data['author_email'] ) : '',
            'body'         => isset( $data['body'] ) ? sanitize_textarea_field( $data['body'] ) : '',
            'is_internal'  => isset( $data['is_internal'] ) ? (int) $data['is_internal'] : 0,
        ) );
        return $wpdb->insert_id ? $wpdb->insert_id : false;
    }

    public static function get_comments( $task_id, $include_internal = true ) {
        global $wpdb;
        $where = $wpdb->prepare( 'task_id = %d', $task_id );
        if ( ! $include_internal ) {
            $where .= ' AND is_internal = 0';
        }
        $results = $wpdb->get_results(
            "SELECT * FROM " . WWPS_DB::comments_table() . " WHERE $where ORDER BY created_at ASC"
        );
        return $results ? $results : array();
    }

    public static function get_overdue( $hours = 48 ) {
        global $wpdb;
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT t.*, p.name as project_name, p.support_email
                 FROM " . WWPS_DB::tasks_table() . " t
                 JOIN " . WWPS_DB::projects_table() . " p ON p.id = t.project_id
                 WHERE t.status = 'open' AND t.created_at < DATE_SUB(NOW(), INTERVAL %d HOUR)
                 ORDER BY FIELD(t.priority,'critical','hot','warm','cold'), t.created_at ASC",
                $hours
            )
        );
        return $results ? $results : array();
    }

    private static function upsert_page( $project_id, $url, $title ) {
        global $wpdb;
        $table = WWPS_DB::pages_table();
        $existing = $wpdb->get_var(
            $wpdb->prepare( "SELECT id FROM $table WHERE project_id = %d AND page_url = %s", $project_id, $url )
        );
        if ( ! $existing ) {
            $wpdb->insert( $table, array(
                'project_id' => $project_id,
                'page_url'   => $url,
                'page_title' => $title,
                'status'     => 'pending',
            ) );
        }
    }

    private static function write_backup( $task_id, $data, $ticket_id ) {
        $dir = WP_CONTENT_DIR . '/wwps-backups';
        if ( ! file_exists( $dir ) ) {
            wp_mkdir_p( $dir );
        }
        $htaccess = $dir . '/.htaccess';
        if ( ! file_exists( $htaccess ) ) {
            file_put_contents( $htaccess, "Deny from all\n" );
        }
        $project_id = isset( $data['project_id'] ) ? (int) $data['project_id'] : 0;
        $file   = $dir . '/project-' . $project_id . '.jsonl';
        $record = array_merge( $data, array(
            'task_id'   => $task_id,
            'ticket_id' => $ticket_id,
            'backed_up' => date( 'c' ),
        ) );
        file_put_contents( $file, json_encode( $record ) . "\n", FILE_APPEND | LOCK_EX );
    }

    public static function priority_label( $priority ) {
        switch ( $priority ) {
            case 'critical': return 'Critical';
            case 'hot':      return 'Hot';
            case 'warm':     return 'Warm';
            case 'cold':     return 'Cold';
            default:         return ucfirst( $priority );
        }
    }

    public static function priority_color( $priority ) {
        switch ( $priority ) {
            case 'critical': return '#e53e3e';
            case 'hot':      return '#dd6b20';
            case 'warm':     return '#d69e2e';
            case 'cold':     return '#3182ce';
            default:         return '#718096';
        }
    }

    public static function priority_badge( $priority ) {
        $color = self::priority_color( $priority );
        $label = self::priority_label( $priority );
        return "<span style='background:{$color};color:#fff;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;'>{$label}</span>";
    }
}
