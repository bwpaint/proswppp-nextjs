<?php
defined( 'ABSPATH' ) || exit;

class WWPS_REST_API {

    public static function init() {
        add_action( 'init',          array( __CLASS__, 'handle_cors_early' ), 1 );
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    /**
     * Fires on 'init' (before WordPress can reject the request) so that:
     *  1. OPTIONS preflight requests get a proper 200 + CORS headers and exit.
     *  2. All REST API responses from this plugin include CORS headers.
     */
    public static function handle_cors_early() {
        $origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? $_SERVER['HTTP_ORIGIN'] : '';
        if ( ! $origin ) {
            return;
        }
        // Only act on requests to our REST namespace.
        $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';
        if ( strpos( $request_uri, 'webwize-proof/v1' ) === false ) {
            return;
        }
        global $wpdb;
        $allowed = $wpdb->get_col(
            "SELECT frontend_url FROM " . WWPS_DB::projects_table() . " WHERE frontend_url != ''"
        );
        foreach ( $allowed as $url ) {
            $url_host = parse_url( rtrim( $url, '/' ), PHP_URL_HOST );
            $origin_host = parse_url( $origin, PHP_URL_HOST );
            if ( $url_host && $origin_host && $url_host === $origin_host ) {
                header( 'Access-Control-Allow-Origin: ' . esc_url_raw( $origin ) );
                header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS' );
                header( 'Access-Control-Allow-Headers: Content-Type, X-WP-Nonce, Authorization' );
                header( 'Access-Control-Allow-Credentials: true' );
                if ( isset( $_SERVER['REQUEST_METHOD'] ) && strtoupper( $_SERVER['REQUEST_METHOD'] ) === 'OPTIONS' ) {
                    status_header( 200 );
                    exit;
                }
                break;
            }
        }
    }

    public static function register_routes() {
        $ns = 'webwize-proof/v1';
        register_rest_route( $ns, '/validate',     array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'validate_token' ),  'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/submit',       array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'submit_task' ),     'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/tasks',        array( 'methods' => 'GET',  'callback' => array( __CLASS__, 'get_tasks' ),       'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/complete',     array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'complete_task' ),   'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/approve-page', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'approve_page' ),    'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/comment',      array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'add_comment' ),     'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/upload',       array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'upload_image' ),    'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/support',       array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'submit_support' ),  'permission_callback' => '__return_true' ) );
        register_rest_route( $ns, '/update-status', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'update_status' ),   'permission_callback' => '__return_true' ) );
    }

    public static function validate_token( $req ) {
        $token = sanitize_text_field( $req->get_param( 'token' ) ? $req->get_param( 'token' ) : '' );
        $mode  = sanitize_text_field( $req->get_param( 'mode' )  ? $req->get_param( 'mode' )  : 'proof' );
        if ( empty( $token ) ) {
            return new WP_REST_Response( array( 'valid' => false, 'error' => 'No token provided' ), 400 );
        }
        $project = $mode === 'review'
            ? WWPS_Tokens::get_project_by_review_token( $token )
            : WWPS_Tokens::get_project_by_proof_token( $token );
        if ( ! $project ) {
            return new WP_REST_Response( array( 'valid' => false, 'error' => 'Invalid token' ), 401 );
        }
        return new WP_REST_Response( array(
            'valid'        => true,
            'project_id'   => (int) $project->id,
            'project_name' => $project->name,
            'client_name'  => $project->client_name,
            'mode'         => $mode,
        ) );
    }

    public static function submit_task( $req ) {
        $token   = sanitize_text_field( $req->get_param( 'proof_token' ) ? $req->get_param( 'proof_token' ) : '' );
        $project = WWPS_Tokens::get_project_by_proof_token( $token );
        if ( ! $project ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Invalid token' ), 401 );
        }
        $params = $req->get_params();
        $params['project_id'] = $project->id;
        if ( ! empty( $params['image_url'] ) ) {
            $params['image_url'] = esc_url_raw( $params['image_url'] );
        }
        $task_id = WWPS_Tasks::create( $params );
        if ( ! $task_id ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Failed to save task' ), 500 );
        }
        $task = WWPS_Tasks::get( $task_id );
        do_action( 'wwps_task_submitted', $task_id, $project );
        return new WP_REST_Response( array( 'success' => true, 'task_id' => $task_id, 'ticket_id' => $task->ticket_id ) );
    }

    public static function get_tasks( $req ) {
        $token   = sanitize_text_field( $req->get_param( 'token' ) ? $req->get_param( 'token' ) : '' );
        $project = WWPS_Tokens::get_project_by_review_token( $token );
        if ( ! $project ) {
            return new WP_REST_Response( array( 'error' => 'Invalid token' ), 401 );
        }
        $page_url = $req->get_param( 'page_url' ) ? sanitize_url( $req->get_param( 'page_url' ) ) : '';
        if ( $page_url ) {
            $tasks = WWPS_Tasks::get_for_page( (int) $project->id, $page_url );
        } else {
            $tasks = WWPS_Tasks::get_for_project( (int) $project->id, array(
                'status'   => $req->get_param( 'status' )   ? $req->get_param( 'status' )   : 'open',
                'priority' => $req->get_param( 'priority' ) ? $req->get_param( 'priority' ) : 'all',
            ) );
        }
        return new WP_REST_Response( array( 'tasks' => $tasks, 'project_name' => $project->name ) );
    }

    public static function complete_task( $req ) {
        $token   = sanitize_text_field( $req->get_param( 'token' ) ? $req->get_param( 'token' ) : '' );
        $task_id = (int) $req->get_param( 'task_id' );
        $project = WWPS_Tokens::get_project_by_review_token( $token );
        if ( ! $project ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Invalid token' ), 401 );
        }
        $task = WWPS_Tasks::get( $task_id );
        if ( ! $task || (int) $task->project_id !== (int) $project->id ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Task not found' ), 404 );
        }
        $done = WWPS_Tasks::complete( $task_id, 'WebWize Team' );
        if ( $done ) {
            do_action( 'wwps_task_completed', $task_id, $project );
        }
        return new WP_REST_Response( array( 'success' => $done ) );
    }

    public static function update_status( $req ) {
        $token      = sanitize_text_field( $req->get_param( 'token' ) ? $req->get_param( 'token' ) : '' );
        $task_id    = (int) $req->get_param( 'task_id' );
        $new_status = sanitize_text_field( $req->get_param( 'status' ) ? $req->get_param( 'status' ) : '' );
        $allowed    = array( 'open', 'completed', 'on_hold', 'wont_fix' );

        $project = WWPS_Tokens::get_project_by_review_token( $token );
        if ( ! $project ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Invalid token' ), 401 );
        }
        if ( ! in_array( $new_status, $allowed, true ) ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Invalid status' ), 400 );
        }
        $task = WWPS_Tasks::get( $task_id );
        if ( ! $task || (int) $task->project_id !== (int) $project->id ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Task not found' ), 404 );
        }

        global $wpdb;
        $table = WWPS_DB::tasks_table();
        $data  = array( 'status' => $new_status );
        if ( $new_status === 'completed' ) {
            $data['completed_by'] = 'WebWize Team';
            $data['completed_at'] = current_time( 'mysql' );
            do_action( 'wwps_task_completed', $task_id, $project );
        }
        $done = $wpdb->update( $table, $data, array( 'id' => $task_id ) );
        return new WP_REST_Response( array( 'success' => $done !== false ) );
    }

    public static function approve_page( $req ) {
        $token    = sanitize_text_field( $req->get_param( 'token' ) ? $req->get_param( 'token' ) : '' );
        $page_url = $req->get_param( 'page_url' ) ? sanitize_url( $req->get_param( 'page_url' ) ) : '';
        $project  = WWPS_Tokens::get_project_by_review_token( $token );
        if ( ! $project ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Invalid token' ), 401 );
        }
        global $wpdb;
        $table    = WWPS_DB::pages_table();
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE project_id = %d AND page_url = %s", $project->id, $page_url ) );
        if ( $existing ) {
            $wpdb->update( $table, array( 'status' => 'approved', 'approved_by' => 'WebWize Team', 'approved_at' => current_time( 'mysql' ) ), array( 'id' => $existing ) );
        } else {
            $wpdb->insert( $table, array( 'project_id' => $project->id, 'page_url' => $page_url, 'status' => 'approved', 'approved_by' => 'WebWize Team', 'approved_at' => current_time( 'mysql' ) ) );
            $wpdb->query( $wpdb->prepare( "UPDATE " . WWPS_DB::projects_table() . " SET pages_approved = pages_approved + 1 WHERE id = %d", $project->id ) );
        }
        return new WP_REST_Response( array( 'success' => true ) );
    }

    public static function add_comment( $req ) {
        $token   = sanitize_text_field( $req->get_param( 'token' ) ? $req->get_param( 'token' ) : '' );
        $task_id = (int) $req->get_param( 'task_id' );
        $project = WWPS_Tokens::get_project_by_review_token( $token );
        if ( ! $project ) {
            $project = WWPS_Tokens::get_project_by_proof_token( $token );
        }
        if ( ! $project ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Invalid token' ), 401 );
        }
        $comment_id = WWPS_Tasks::add_comment( $task_id, $req->get_params() );
        return new WP_REST_Response( array( 'success' => (bool) $comment_id, 'comment_id' => $comment_id ) );
    }

    public static function submit_support( $req ) {
        $token   = sanitize_text_field( $req->get_param( 'token' ) ? $req->get_param( 'token' ) : '' );
        $project = WWPS_Tokens::get_project_by_review_token( $token );
        if ( ! $project ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Invalid token' ), 401 );
        }

        $subject = sanitize_text_field( $req->get_param( 'subject' ) ? $req->get_param( 'subject' ) : '' );
        $message = sanitize_textarea_field( $req->get_param( 'message' ) ? $req->get_param( 'message' ) : '' );
        if ( empty( $subject ) || empty( $message ) ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Subject and message are required' ), 400 );
        }

        $params = array(
            'project_id'   => $project->id,
            'page_url'     => sanitize_url( $req->get_param( 'page_url' ) ? $req->get_param( 'page_url' ) : '' ),
            'page_title'   => sanitize_text_field( $req->get_param( 'page_title' ) ? $req->get_param( 'page_title' ) : '' ),
            'comment'      => '[SUPPORT] ' . $subject . "\n\n" . $message,
            'priority'     => 'warm',
            'author_name'  => sanitize_text_field( $req->get_param( 'author_name' )  ? $req->get_param( 'author_name' )  : 'Anonymous' ),
            'author_email' => sanitize_email( $req->get_param( 'author_email' ) ? $req->get_param( 'author_email' ) : '' ),
            'element_tag'  => 'support',
        );

        $task_id = WWPS_Tasks::create( $params );
        if ( ! $task_id ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Failed to save ticket' ), 500 );
        }

        $task = WWPS_Tasks::get( $task_id );
        do_action( 'wwps_support_submitted', $task_id, $project );

        return new WP_REST_Response( array(
            'success'   => true,
            'task_id'   => $task_id,
            'ticket_id' => $task->ticket_id,
        ) );
    }

    public static function upload_image( $req ) {
        // Validate proof token
        $token   = sanitize_text_field( isset( $_POST['proof_token'] ) ? $_POST['proof_token'] : '' );
        $project = WWPS_Tokens::get_project_by_proof_token( $token );
        if ( ! $project ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Invalid token' ), 401 );
        }

        // Check file was provided
        if ( empty( $_FILES['image'] ) || $_FILES['image']['error'] !== UPLOAD_ERR_OK ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'No file received' ), 400 );
        }

        $file = $_FILES['image'];

        // Server-side size check (300 KB)
        if ( $file['size'] > 300 * 1024 ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'File exceeds 300KB limit' ), 400 );
        }

        // Verify actual file content using magic bytes — rejects renamed scripts
        if ( ! function_exists( 'finfo_open' ) ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Server cannot verify file type' ), 500 );
        }
        $finfo     = new finfo( FILEINFO_MIME_TYPE );
        $real_mime = $finfo->file( $file['tmp_name'] );
        $allowed   = array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp' );
        if ( ! in_array( $real_mime, $allowed, true ) ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Invalid file type. Only JPEG, PNG, GIF, and WebP images are allowed.' ), 400 );
        }

        // Load WordPress upload helpers
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        $overrides = array(
            'test_form' => false,
            'mimes'     => array(
                'jpg|jpeg|jpe' => 'image/jpeg',
                'png'          => 'image/png',
                'gif'          => 'image/gif',
                'webp'         => 'image/webp',
            ),
        );

        $upload = wp_handle_upload( $file, $overrides );

        if ( isset( $upload['error'] ) ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => $upload['error'] ), 500 );
        }

        // Insert into media library
        $attachment_id = wp_insert_attachment( array(
            'post_mime_type' => $upload['type'],
            'post_title'     => 'Proof Upload — ' . sanitize_text_field( $project->name ),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ), $upload['file'] );

        if ( is_wp_error( $attachment_id ) ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Could not save to media library' ), 500 );
        }

        wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $upload['file'] ) );

        return new WP_REST_Response( array(
            'success'       => true,
            'url'           => $upload['url'],
            'attachment_id' => $attachment_id,
        ) );
    }
}
