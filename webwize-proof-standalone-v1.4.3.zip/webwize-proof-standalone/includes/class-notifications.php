<?php
defined( 'ABSPATH' ) || exit;

class WWPS_Notifications {

    public static function init() {
        add_action( 'wwps_task_submitted',    array( __CLASS__, 'on_task_submitted'  ), 10, 2 );
        add_action( 'wwps_task_completed',    array( __CLASS__, 'on_task_completed'  ), 10, 2 );
        add_action( 'wwps_support_submitted', array( __CLASS__, 'on_task_submitted'  ), 10, 2 ); // same email, different hook
        add_action( 'wwps_overdue_digest',    array( __CLASS__, 'send_overdue_digest' ) );
    }

    // -------------------------------------------------------------------------
    // Event: Task Submitted (also handles Support Tickets via same hook)
    // -------------------------------------------------------------------------

    public static function on_task_submitted( $task_id, $project ) {
        if ( ! WWPS_Notification_Settings::is_enabled( 'task_submitted' ) ) return;

        $task = WWPS_Tasks::get( $task_id );
        if ( ! $task ) return;

        $subject = '[' . $task->ticket_id . '] New feedback — ' . self::priority_label( $task->priority ) . ' on ' . $task->page_title;

        $body  = self::header();
        $body .= '<h2 style="color:#e94560;margin:0 0 16px;">New Proof Task</h2>';
        $body .= '<table style="width:100%;border-collapse:collapse;margin-bottom:20px;">';
        $body .= self::row( 'Ticket',   $task->ticket_id );
        $body .= self::row( 'Project',  esc_html( $project->name ) );
        $body .= self::row( 'Page',     '<a href="' . esc_url( $task->page_url ) . '">' . esc_html( $task->page_title ? $task->page_title : $task->page_url ) . '</a>' );
        $body .= self::row( 'Priority', WWPS_Tasks::priority_badge( $task->priority ) );
        $body .= self::row( 'From',     esc_html( $task->author_name ) . ' &lt;' . esc_html( $task->author_email ) . '&gt;' );
        $body .= self::row( 'Element',  esc_html( $task->element_tag ) . ( $task->element_text_before ? ' — "...' . esc_html( $task->element_text_before ) . '..."' : '' ) );
        $body .= self::row( 'Device',   esc_html( $task->device_type ) . ' — ' . esc_html( $task->browser ) . ' — ' . $task->viewport_width . 'x' . $task->viewport_height );
        $body .= '</table>';
        $body .= '<div style="background:#f7f7f7;border-left:4px solid #e94560;padding:12px 16px;border-radius:0 4px 4px 0;margin-bottom:20px;">';
        $body .= '<strong>Comment:</strong><br>' . nl2br( esc_html( $task->comment ) );
        $body .= '</div>';

        if ( ! empty( $task->image_url ) ) {
            $body .= '<div style="margin-bottom:20px;"><strong>Attached Image:</strong><br><a href="' . esc_url( $task->image_url ) . '" target="_blank"><img src="' . esc_url( $task->image_url ) . '" style="max-width:400px;border-radius:4px;margin-top:8px;"></a></div>';
        }

        $review_url = WWPS_Tokens::get_review_url( $project, $task->page_url );
        $admin_url  = admin_url( 'admin.php?page=wwps-tasks&task=' . $task_id );
        $body .= '<a href="' . esc_url( $review_url ) . '" style="background:#e94560;color:#fff;padding:10px 20px;border-radius:4px;text-decoration:none;font-weight:600;display:inline-block;margin-bottom:8px;margin-right:8px;">Review on Page</a>';
        $body .= '<a href="' . esc_url( $admin_url )  . '" style="background:#333;color:#fff;padding:10px 20px;border-radius:4px;text-decoration:none;font-weight:600;display:inline-block;margin-bottom:24px;">View in WP Admin</a>';
        $body .= self::footer();

        self::dispatch( 'task_submitted', $task_id, (int) $project->id, $task->ticket_id, $subject, $body );
    }

    // -------------------------------------------------------------------------
    // Event: Task Completed
    // -------------------------------------------------------------------------

    public static function on_task_completed( $task_id, $project ) {
        $task = WWPS_Tasks::get( $task_id );
        if ( ! $task ) return;

        // 1. Notify the submitter (if email available) — always, regardless of team settings
        if ( is_email( $task->author_email ) ) {
            $subject = '[' . $task->ticket_id . '] Your feedback has been resolved';
            $body  = self::header();
            $body .= '<h2 style="color:#38a169;margin:0 0 16px;">Feedback Resolved</h2>';
            $body .= '<p>Hi ' . esc_html( $task->author_name ) . ',</p>';
            $body .= '<p>Your feedback on <strong>' . esc_html( $task->page_title ? $task->page_title : $task->page_url ) . '</strong> has been marked as complete.</p>';
            $body .= '<table style="width:100%;border-collapse:collapse;margin-bottom:20px;">';
            $body .= self::row( 'Ticket',   $task->ticket_id );
            $body .= self::row( 'Resolved', $task->completed_at );
            $snippet = mb_substr( $task->comment, 0, 80 );
            $body .= self::row( 'Your note', '"' . esc_html( $snippet ) . ( mb_strlen( $task->comment ) > 80 ? '...' : '' ) . '"' );
            $body .= '</table>';
            $body .= self::footer();
            self::send( $task->author_email, $subject, $body, $task_id, (int) $project->id, $task->ticket_id, 'task_completed' );
        }

        // 2. Notify configured teams (if event enabled)
        if ( ! WWPS_Notification_Settings::is_enabled( 'task_completed' ) ) return;

        $subject = '[' . $task->ticket_id . '] Task completed — ' . esc_html( $task->page_title );
        $body  = self::header();
        $body .= '<h2 style="color:#38a169;margin:0 0 16px;">Task Completed</h2>';
        $body .= '<table style="width:100%;border-collapse:collapse;margin-bottom:20px;">';
        $body .= self::row( 'Ticket',    $task->ticket_id );
        $body .= self::row( 'Project',   esc_html( $project->name ) );
        $body .= self::row( 'Page',      '<a href="' . esc_url( $task->page_url ) . '">' . esc_html( $task->page_title ) . '</a>' );
        $body .= self::row( 'From',      esc_html( $task->author_name ) );
        $body .= self::row( 'Completed', esc_html( $task->completed_at ) . ' by ' . esc_html( $task->completed_by ) );
        $body .= '</table>';
        $body .= self::footer();

        self::dispatch( 'task_completed', $task_id, (int) $project->id, $task->ticket_id, $subject, $body );
    }

    // -------------------------------------------------------------------------
    // Overdue digest — send to Webmaster team, fallback to admin email
    // -------------------------------------------------------------------------

    public static function send_overdue_digest() {
        $hours = (int) get_option( 'wwps_overdue_hours', 48 );
        $tasks = WWPS_Tasks::get_overdue( $hours );
        if ( empty( $tasks ) ) return;

        $grouped = array();
        foreach ( $tasks as $task ) {
            $grouped[ $task->project_id ][] = $task;
        }

        // Webmaster team members get the digest
        $contacts = WWPS_Contacts::get_for_event( 'task_submitted' ); // use same team config as submitted
        if ( empty( $contacts ) ) {
            // Fallback: site admin
            $contacts = array( (object) array( 'name' => 'Admin', 'email' => get_option( 'admin_email' ) ) );
        }

        foreach ( $grouped as $project_id => $project_tasks ) {
            $project = WWPS_Tokens::get_project_by_id( $project_id );
            $subject = '[WebWize Proof] Overdue tasks — ' . count( $project_tasks ) . ' open';

            $body  = self::header();
            $body .= '<h2 style="color:#e94560;margin:0 0 8px;">Overdue Tasks Digest</h2>';
            $body .= '<p>' . count( $project_tasks ) . ' tasks open &gt; ' . $hours . ' hours for <strong>' . esc_html( $project->name ) . '</strong></p>';
            $body .= '<table style="width:100%;border-collapse:collapse;">';
            $body .= '<tr style="background:#0f172a;color:#fff;"><th style="padding:8px;text-align:left;">Ticket</th><th style="padding:8px;text-align:left;">Page</th><th style="padding:8px;text-align:left;">Priority</th><th style="padding:8px;text-align:left;">Age</th></tr>';
            foreach ( $project_tasks as $i => $t ) {
                $bg  = $i % 2 === 0 ? '#fff' : '#f9f9f9';
                $age = human_time_diff( strtotime( $t->created_at ) );
                $body .= '<tr style="background:' . $bg . ';">';
                $body .= '<td style="padding:8px;border-bottom:1px solid #eee;"><code>' . $t->ticket_id . '</code></td>';
                $body .= '<td style="padding:8px;border-bottom:1px solid #eee;"><a href="' . esc_url( $t->page_url ) . '">' . esc_html( $t->page_title ? $t->page_title : $t->page_url ) . '</a></td>';
                $body .= '<td style="padding:8px;border-bottom:1px solid #eee;">' . WWPS_Tasks::priority_badge( $t->priority ) . '</td>';
                $body .= '<td style="padding:8px;border-bottom:1px solid #eee;">' . $age . '</td>';
                $body .= '</tr>';
            }
            $body .= '</table>';
            $body .= self::footer();

            foreach ( $contacts as $contact ) {
                self::send( $contact->email, $subject, $body, null, $project_id, '', 'overdue_digest' );
            }
        }
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    /**
     * Look up all contacts for an event's assigned teams and send to each one.
     */
    private static function dispatch( $event_type, $task_id, $project_id, $ticket_id, $subject, $body ) {
        $contacts = WWPS_Contacts::get_for_event( $event_type );
        if ( empty( $contacts ) ) {
            // Fallback: site admin email so nothing gets silently dropped
            self::send( get_option( 'admin_email' ), $subject, $body, $task_id, $project_id, $ticket_id, $event_type );
            return;
        }
        $sent_to = array();
        foreach ( $contacts as $contact ) {
            if ( in_array( $contact->email, $sent_to, true ) ) continue;
            $sent_to[] = $contact->email;
            self::send( $contact->email, $subject, $body, $task_id, $project_id, $ticket_id, $event_type );
        }
    }

    private static function send( $to, $subject, $body, $task_id, $project_id, $ticket_id, $template ) {
        if ( ! is_email( $to ) ) return;
        $headers = array( 'Content-Type: text/html; charset=UTF-8' );
        $sent    = wp_mail( $to, $subject, $body, $headers );
        global $wpdb;
        $wpdb->insert( WWPS_DB::log_table(), array(
            'project_id'      => $project_id,
            'task_id'         => $task_id,
            'ticket_id'       => $ticket_id,
            'recipient_email' => $to,
            'template'        => $template,
            'subject'         => $subject,
            'status'          => $sent ? 'sent' : 'failed',
            'error'           => $sent ? null : 'wp_mail returned false',
        ) );
    }

    private static function header() {
        return '<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;font-size:14px;color:#333;max-width:600px;margin:0 auto;padding:20px;">'
             . '<div style="border-bottom:3px solid #e94560;padding-bottom:12px;margin-bottom:24px;">'
             . '<strong style="font-size:18px;letter-spacing:1px;">WEBWIZE</strong> <span style="color:#e94560;font-weight:700;">PROOF</span>'
             . '</div>';
    }

    private static function footer() {
        return '<p style="color:#999;font-size:12px;border-top:1px solid #eee;padding-top:16px;margin-top:24px;">'
             . 'This notification was sent by WebWize Proof on ' . get_bloginfo( 'name' ) . '.'
             . '</p></body></html>';
    }

    private static function row( $label, $value ) {
        return '<tr><td style="padding:6px 8px;font-weight:600;width:120px;border-bottom:1px solid #eee;">' . $label . '</td>'
             . '<td style="padding:6px 8px;border-bottom:1px solid #eee;">' . $value . '</td></tr>';
    }

    private static function priority_label( $p ) {
        return WWPS_Tasks::priority_label( $p );
    }
}
