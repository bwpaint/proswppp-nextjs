<?php
defined( 'ABSPATH' ) || exit;

class WWPS_Teams {

    public static function get_all() {
        global $wpdb;
        $results = $wpdb->get_results(
            "SELECT * FROM " . WWPS_DB::teams_table() . " ORDER BY sort_order ASC, id ASC"
        );
        return $results ? $results : array();
    }

    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM " . WWPS_DB::teams_table() . " WHERE id = %d", $id )
        );
    }

    public static function create( $name ) {
        global $wpdb;
        $max_order = (int) $wpdb->get_var( "SELECT MAX(sort_order) FROM " . WWPS_DB::teams_table() );
        $inserted  = $wpdb->insert( WWPS_DB::teams_table(), array(
            'name'           => sanitize_text_field( $name ),
            'is_name_locked' => 0,
            'sort_order'     => $max_order + 1,
        ) );
        return $inserted ? $wpdb->insert_id : false;
    }

    public static function update_name( $id, $name ) {
        global $wpdb;
        $team = self::get( $id );
        if ( ! $team || $team->is_name_locked ) {
            return false; // locked teams cannot be renamed
        }
        return $wpdb->update(
            WWPS_DB::teams_table(),
            array( 'name' => sanitize_text_field( $name ) ),
            array( 'id'   => (int) $id )
        );
    }

    /**
     * Add a contact to a team. Silently ignores duplicates.
     */
    public static function add_member( $team_id, $contact_id ) {
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM " . WWPS_DB::team_members_table() . " WHERE team_id = %d AND contact_id = %d",
            $team_id, $contact_id
        ) );
        if ( $exists ) {
            return true;
        }
        return (bool) $wpdb->insert( WWPS_DB::team_members_table(), array(
            'team_id'    => (int) $team_id,
            'contact_id' => (int) $contact_id,
        ) );
    }

    /**
     * Remove a contact from a team.
     */
    public static function remove_member( $team_id, $contact_id ) {
        global $wpdb;
        return $wpdb->delete( WWPS_DB::team_members_table(), array(
            'team_id'    => (int) $team_id,
            'contact_id' => (int) $contact_id,
        ) );
    }

    /**
     * Return all team IDs that receive a given event.
     */
    public static function get_for_event( $event_type ) {
        global $wpdb;
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT t.* FROM " . WWPS_DB::teams_table() . " t
                 INNER JOIN " . WWPS_DB::notification_teams_table() . " nt ON nt.team_id = t.id
                 WHERE nt.event_type = %s
                 ORDER BY t.sort_order ASC",
                $event_type
            )
        );
        return $results ? $results : array();
    }

    /**
     * Assign a team to an event. Silently ignores duplicates.
     */
    public static function assign_to_event( $event_type, $team_id ) {
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM " . WWPS_DB::notification_teams_table() . " WHERE event_type = %s AND team_id = %d",
            $event_type, $team_id
        ) );
        if ( $exists ) {
            return true;
        }
        return (bool) $wpdb->insert( WWPS_DB::notification_teams_table(), array(
            'event_type' => sanitize_text_field( $event_type ),
            'team_id'    => (int) $team_id,
        ) );
    }

    /**
     * Remove a team from an event.
     */
    public static function remove_from_event( $event_type, $team_id ) {
        global $wpdb;
        return $wpdb->delete( WWPS_DB::notification_teams_table(), array(
            'event_type' => sanitize_text_field( $event_type ),
            'team_id'    => (int) $team_id,
        ) );
    }
}
