<?php
defined( 'ABSPATH' ) || exit;

class WWPS_Contacts {

    public static function get_all() {
        global $wpdb;
        $results = $wpdb->get_results(
            "SELECT * FROM " . WWPS_DB::contacts_table() . " ORDER BY name ASC"
        );
        return $results ? $results : array();
    }

    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM " . WWPS_DB::contacts_table() . " WHERE id = %d", $id )
        );
    }

    public static function create( $name, $email ) {
        global $wpdb;
        $inserted = $wpdb->insert( WWPS_DB::contacts_table(), array(
            'name'  => sanitize_text_field( $name ),
            'email' => sanitize_email( $email ),
        ) );
        return $inserted ? $wpdb->insert_id : false;
    }

    public static function update( $id, $name, $email ) {
        global $wpdb;
        return $wpdb->update(
            WWPS_DB::contacts_table(),
            array( 'name' => sanitize_text_field( $name ), 'email' => sanitize_email( $email ) ),
            array( 'id'   => (int) $id )
        );
    }

    public static function delete( $id ) {
        global $wpdb;
        // Remove from all team memberships first
        $wpdb->delete( WWPS_DB::team_members_table(), array( 'contact_id' => (int) $id ) );
        return $wpdb->delete( WWPS_DB::contacts_table(), array( 'id' => (int) $id ) );
    }

    /**
     * Return all contacts for a given team.
     */
    public static function get_for_team( $team_id ) {
        global $wpdb;
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT c.* FROM " . WWPS_DB::contacts_table() . " c
                 INNER JOIN " . WWPS_DB::team_members_table() . " tm ON tm.contact_id = c.id
                 WHERE tm.team_id = %d
                 ORDER BY c.name ASC",
                $team_id
            )
        );
        return $results ? $results : array();
    }

    /**
     * Return all contacts assigned to any team that receives the given event.
     * De-duped by email.
     */
    public static function get_for_event( $event_type ) {
        global $wpdb;
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DISTINCT c.name, c.email
                 FROM " . WWPS_DB::contacts_table() . " c
                 INNER JOIN " . WWPS_DB::team_members_table() . " tm ON tm.contact_id = c.id
                 INNER JOIN " . WWPS_DB::notification_teams_table() . " nt ON nt.team_id = tm.team_id
                 WHERE nt.event_type = %s
                 ORDER BY c.name ASC",
                $event_type
            )
        );
        return $results ? $results : array();
    }
}
