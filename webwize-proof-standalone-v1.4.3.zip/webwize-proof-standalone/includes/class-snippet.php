<?php
defined( 'ABSPATH' ) || exit;

class WWPS_Snippet {

    public static function init() {
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ), 99 );
    }

    /**
     * Always enqueues the tiny launcher script on every front-end page.
     * The launcher reads proof/review tokens from URL params or a 7-day cookie
     * entirely client-side, then dynamically loads the full proof.js.
     *
     * This approach is cache-safe: no server-side cookie reading or conditional
     * enqueuing — cached pages work just as well as uncached ones.
     */
    public static function enqueue() {
        wp_enqueue_script(
            'wwps-launcher',
            WWPS_PLUGIN_URL . 'assets/launcher.js',
            array(),
            WWPS_VERSION,
            true   // footer
        );

        // Pass server-side values the launcher needs (REST URL, nonce, proof.js URL).
        // wp_localize_script outputs a small inline <script> — negligible overhead.
        wp_localize_script( 'wwps-launcher', 'wwpsLauncherCfg', array(
            'ajaxUrl'  => rest_url( 'webwize-proof/v1' ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
            'proofSrc' => WWPS_PLUGIN_URL . 'assets/proof.js?ver=' . WWPS_VERSION,
        ) );
    }
}
