<?php
defined( 'ABSPATH' ) || exit;

class WWPS_DB {

    const DB_VERSION = '1.3.0';

    public static function install() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta( "CREATE TABLE {$wpdb->prefix}wwps_projects (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL DEFAULT '',
            frontend_url VARCHAR(2048) NOT NULL DEFAULT '',
            client_name VARCHAR(255) NOT NULL DEFAULT '',
            client_emails TEXT NOT NULL,
            support_email VARCHAR(255) NOT NULL DEFAULT '',
            proof_token VARCHAR(64) NOT NULL DEFAULT '',
            review_token VARCHAR(64) NOT NULL DEFAULT '',
            tasks_open INT UNSIGNED NOT NULL DEFAULT 0,
            tasks_completed INT UNSIGNED NOT NULL DEFAULT 0,
            pages_approved INT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY proof_token (proof_token),
            UNIQUE KEY review_token (review_token)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}wwps_pages (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            project_id BIGINT UNSIGNED NOT NULL,
            page_url VARCHAR(2048) NOT NULL DEFAULT '',
            page_title VARCHAR(255) NOT NULL DEFAULT '',
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            approved_by VARCHAR(255) NOT NULL DEFAULT '',
            approved_at DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY project_id (project_id)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}wwps_tasks (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            project_id BIGINT UNSIGNED NOT NULL,
            ticket_id VARCHAR(20) NOT NULL DEFAULT '',
            page_url VARCHAR(2048) NOT NULL DEFAULT '',
            page_title VARCHAR(255) NOT NULL DEFAULT '',
            element_selector VARCHAR(512) NOT NULL DEFAULT '',
            element_tag VARCHAR(50) NOT NULL DEFAULT '',
            element_text_before VARCHAR(60) NOT NULL DEFAULT '',
            element_text_after VARCHAR(60) NOT NULL DEFAULT '',
            scroll_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
            viewport_x_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
            viewport_y_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
            device_type VARCHAR(20) NOT NULL DEFAULT 'desktop',
            viewport_width SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            viewport_height SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            pixel_ratio DECIMAL(4,2) NOT NULL DEFAULT 1.00,
            browser VARCHAR(50) NOT NULL DEFAULT '',
            os VARCHAR(50) NOT NULL DEFAULT '',
            priority VARCHAR(10) NOT NULL DEFAULT 'warm',
            status VARCHAR(20) NOT NULL DEFAULT 'open',
            author_name VARCHAR(255) NOT NULL DEFAULT '',
            author_email VARCHAR(255) NOT NULL DEFAULT '',
            comment TEXT NOT NULL,
            image_url VARCHAR(2048) NOT NULL DEFAULT '',
            is_internal TINYINT(1) NOT NULL DEFAULT 0,
            completed_by VARCHAR(255) NOT NULL DEFAULT '',
            completed_at DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY project_id (project_id),
            KEY status (status),
            KEY priority (priority),
            KEY ticket_id (ticket_id)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}wwps_comments (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            task_id BIGINT UNSIGNED NOT NULL,
            author_name VARCHAR(255) NOT NULL DEFAULT '',
            author_email VARCHAR(255) NOT NULL DEFAULT '',
            body TEXT NOT NULL,
            is_internal TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY task_id (task_id)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}wwps_notification_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            project_id BIGINT UNSIGNED NULL,
            task_id BIGINT UNSIGNED NULL,
            ticket_id VARCHAR(20) NOT NULL DEFAULT '',
            recipient_email VARCHAR(255) NOT NULL DEFAULT '',
            template VARCHAR(50) NOT NULL DEFAULT '',
            subject VARCHAR(255) NOT NULL DEFAULT '',
            status VARCHAR(10) NOT NULL DEFAULT 'sent',
            error TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY project_id (project_id)
        ) $charset;" );

        // --- Teams / Contacts / Notifications ---

        dbDelta( "CREATE TABLE {$wpdb->prefix}wwps_contacts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL DEFAULT '',
            email VARCHAR(255) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}wwps_teams (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL DEFAULT '',
            is_name_locked TINYINT(1) NOT NULL DEFAULT 0,
            sort_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}wwps_team_members (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            team_id BIGINT UNSIGNED NOT NULL,
            contact_id BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY team_contact (team_id, contact_id),
            KEY team_id (team_id),
            KEY contact_id (contact_id)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}wwps_notification_settings (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_type VARCHAR(50) NOT NULL DEFAULT '',
            enabled TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY event_type (event_type)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}wwps_notification_teams (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_type VARCHAR(50) NOT NULL DEFAULT '',
            team_id BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY event_team (event_type, team_id),
            KEY event_type (event_type),
            KEY team_id (team_id)
        ) $charset;" );

        self::upgrade();
        update_option( 'wwps_db_version', self::DB_VERSION );
        self::maybe_create_default_project();
        self::maybe_seed_teams();
        self::maybe_seed_notification_events();
    }

    public static function upgrade() {
        global $wpdb;

        // v1.1.1 — projects table: frontend_url column
        $proj_table = $wpdb->prefix . 'wwps_projects';
        $proj_cols  = $wpdb->get_col( "SHOW COLUMNS FROM $proj_table", 0 );
        if ( is_array( $proj_cols ) && ! in_array( 'frontend_url', $proj_cols, true ) ) {
            $wpdb->query( "ALTER TABLE $proj_table ADD COLUMN frontend_url VARCHAR(2048) NOT NULL DEFAULT '' AFTER name" );
        }

        // v1.2.0 — tasks table: image_url column
        $task_table = $wpdb->prefix . 'wwps_tasks';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$task_table'" ) === $task_table ) {
            $task_cols = $wpdb->get_col( "SHOW COLUMNS FROM $task_table", 0 );
            if ( is_array( $task_cols ) && ! in_array( 'image_url', $task_cols, true ) ) {
                $wpdb->query( "ALTER TABLE $task_table ADD COLUMN image_url VARCHAR(2048) NOT NULL DEFAULT '' AFTER comment" );
            }
        }

        // v1.3.0 — create new tables if they don't exist yet (live upgrade)
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $contacts_table = $wpdb->prefix . 'wwps_contacts';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$contacts_table'" ) !== $contacts_table ) {
            dbDelta( "CREATE TABLE $contacts_table (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL DEFAULT '',
                email VARCHAR(255) NOT NULL DEFAULT '',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                UNIQUE KEY email (email)
            ) $charset;" );
        }

        $teams_table = $wpdb->prefix . 'wwps_teams';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$teams_table'" ) !== $teams_table ) {
            dbDelta( "CREATE TABLE $teams_table (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL DEFAULT '',
                is_name_locked TINYINT(1) NOT NULL DEFAULT 0,
                sort_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id)
            ) $charset;" );
        }

        $members_table = $wpdb->prefix . 'wwps_team_members';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$members_table'" ) !== $members_table ) {
            dbDelta( "CREATE TABLE $members_table (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                team_id BIGINT UNSIGNED NOT NULL,
                contact_id BIGINT UNSIGNED NOT NULL,
                PRIMARY KEY  (id),
                UNIQUE KEY team_contact (team_id, contact_id),
                KEY team_id (team_id),
                KEY contact_id (contact_id)
            ) $charset;" );
        }

        $notif_settings_table = $wpdb->prefix . 'wwps_notification_settings';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$notif_settings_table'" ) !== $notif_settings_table ) {
            dbDelta( "CREATE TABLE $notif_settings_table (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                event_type VARCHAR(50) NOT NULL DEFAULT '',
                enabled TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                UNIQUE KEY event_type (event_type)
            ) $charset;" );
        }

        $notif_teams_table = $wpdb->prefix . 'wwps_notification_teams';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$notif_teams_table'" ) !== $notif_teams_table ) {
            dbDelta( "CREATE TABLE $notif_teams_table (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                event_type VARCHAR(50) NOT NULL DEFAULT '',
                team_id BIGINT UNSIGNED NOT NULL,
                PRIMARY KEY  (id),
                UNIQUE KEY event_team (event_type, team_id),
                KEY event_type (event_type),
                KEY team_id (team_id)
            ) $charset;" );
        }

        // Seed if tables just got created (live install upgrade)
        self::maybe_seed_teams();
        self::maybe_seed_notification_events();
    }

    // -------------------------------------------------------------------------
    // Seed helpers
    // -------------------------------------------------------------------------

    private static function maybe_seed_teams() {
        global $wpdb;
        $table = $wpdb->prefix . 'wwps_teams';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
            return;
        }
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
        if ( $count > 0 ) {
            return;
        }
        $defaults = array(
            array( 'name' => 'Webmaster', 'is_name_locked' => 1, 'sort_order' => 1 ),
            array( 'name' => 'Internal',  'is_name_locked' => 0, 'sort_order' => 2 ),
            array( 'name' => 'Executive', 'is_name_locked' => 0, 'sort_order' => 3 ),
        );
        foreach ( $defaults as $team ) {
            $wpdb->insert( $table, $team );
        }
    }

    private static function maybe_seed_notification_events() {
        global $wpdb;
        $table = $wpdb->prefix . 'wwps_notification_settings';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
            return;
        }
        $events = array( 'task_submitted', 'task_updated', 'task_completed', 'comment_added' );
        foreach ( $events as $event ) {
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE event_type = %s", $event ) );
            if ( ! $exists ) {
                $wpdb->insert( $table, array( 'event_type' => $event, 'enabled' => 1 ) );
            }
        }
    }

    private static function maybe_create_default_project() {
        global $wpdb;
        $table = $wpdb->prefix . 'wwps_projects';
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
        if ( $count > 0 ) {
            return;
        }
        $proof_token  = bin2hex( random_bytes( 32 ) );
        $review_token = bin2hex( random_bytes( 32 ) );
        $wpdb->insert( $table, array(
            'name'          => 'ProSWPPP Dev Site',
            'client_name'   => 'ProSWPPP',
            'client_emails' => '',
            'support_email' => get_option( 'admin_email' ),
            'proof_token'   => $proof_token,
            'review_token'  => $review_token,
        ) );
        update_option( 'wwps_default_project_id', $wpdb->insert_id );
    }

    // -------------------------------------------------------------------------
    // Table name helpers
    // -------------------------------------------------------------------------

    public static function projects_table() {
        global $wpdb;
        return $wpdb->prefix . 'wwps_projects';
    }

    public static function pages_table() {
        global $wpdb;
        return $wpdb->prefix . 'wwps_pages';
    }

    public static function tasks_table() {
        global $wpdb;
        return $wpdb->prefix . 'wwps_tasks';
    }

    public static function comments_table() {
        global $wpdb;
        return $wpdb->prefix . 'wwps_comments';
    }

    public static function log_table() {
        global $wpdb;
        return $wpdb->prefix . 'wwps_notification_log';
    }

    public static function contacts_table() {
        global $wpdb;
        return $wpdb->prefix . 'wwps_contacts';
    }

    public static function teams_table() {
        global $wpdb;
        return $wpdb->prefix . 'wwps_teams';
    }

    public static function team_members_table() {
        global $wpdb;
        return $wpdb->prefix . 'wwps_team_members';
    }

    public static function notification_settings_table() {
        global $wpdb;
        return $wpdb->prefix . 'wwps_notification_settings';
    }

    public static function notification_teams_table() {
        global $wpdb;
        return $wpdb->prefix . 'wwps_notification_teams';
    }

    public static function next_ticket_id() {
        global $wpdb;
        $year  = date( 'Y' );
        $count = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}wwps_tasks WHERE YEAR(created_at) = %d",
                $year
            )
        );
        return 'WW-' . $year . '-' . str_pad( $count + 1, 5, '0', STR_PAD_LEFT );
    }
}
