/* WebWize Proof -- Admin JS */
(function($){
    'use strict';

    // Copy to clipboard
    $(document).on('click', '.wwps-copy-btn', function(){
        var text = $(this).data('copy');
        var btn  = $(this);
        navigator.clipboard.writeText(text).then(function() {
            var orig = btn.text();
            btn.text('Copied!');
            setTimeout(function(){ btn.text(orig); }, 2000);
        });
    });

    // Mark Complete
    $(document).on('click', '.wwps-complete-btn', function(){
        var btn    = $(this);
        var taskId = btn.data('task');
        if (!confirm('Mark task #' + taskId + ' as complete?')) return;

        btn.prop('disabled', true).text('...');
        $.post(wwpsAdmin.ajaxUrl, {
            action:  'wwps_complete_task',
            nonce:   wwpsAdmin.nonce,
            task_id: taskId,
        }).done(function(res){
            if (res.success) {
                var row = btn.closest('tr, .wwps-kanban-card');
                if (row.length) {
                    row.fadeOut(300, function(){ $(this).remove(); });
                } else {
                    location.reload();
                }
            } else {
                alert('Error completing task.');
                btn.prop('disabled', false).text('Done');
            }
        });
    });

    // Re-open Task
    $(document).on('click', '.wwps-reopen-btn', function(){
        var btn    = $(this);
        var taskId = btn.data('task');
        btn.prop('disabled', true).text('...');
        $.post(wwpsAdmin.ajaxUrl, {
            action:  'wwps_reopen_task',
            nonce:   wwpsAdmin.nonce,
            task_id: taskId,
        }).done(function(res){
            if (res.success) {
                location.reload();
            } else {
                alert('Error reopening task.');
                btn.prop('disabled', false).text('Re-open');
            }
        });
    });

    // Add Comment
    $(document).on('click', '.wwps-comment-submit', function(){
        var btn    = $(this);
        var taskId = btn.data('task');
        var body   = $('#wwps-comment-body').val().trim();
        var intern = $('#wwps-comment-internal').is(':checked') ? 1 : 0;

        if (!body) { alert('Please enter a comment.'); return; }
        btn.prop('disabled', true).text('Adding...');

        $.post(wwpsAdmin.ajaxUrl, {
            action:      'wwps_add_comment',
            nonce:       wwpsAdmin.nonce,
            task_id:     taskId,
            body:        body,
            is_internal: intern,
        }).done(function(res){
            if (res.success) {
                location.reload();
            } else {
                alert('Error adding comment.');
                btn.prop('disabled', false).text('Add Note');
            }
        });
    });

    // Approve Page
    $(document).on('click', '.wwps-approve-page-btn', function(){
        var btn       = $(this);
        var projectId = btn.data('project');
        var pageUrl   = btn.data('url');
        if (!confirm('Approve this page?')) return;
        btn.prop('disabled', true).text('...');
        $.post(wwpsAdmin.ajaxUrl, {
            action:     'wwps_approve_page',
            nonce:      wwpsAdmin.nonce,
            project_id: projectId,
            page_url:   pageUrl,
        }).done(function(res){
            if (res.success) {
                location.reload();
            } else {
                alert('Error approving page.');
                btn.prop('disabled', false).text('Approve Page');
            }
        });
    });

    // Reset Token
    $(document).on('click', '.wwps-reset-token-btn', function(){
        var btn       = $(this);
        var projectId = btn.data('project');
        var type      = btn.data('type');
        btn.prop('disabled', true).text('Resetting...');
        $.post(wwpsAdmin.ajaxUrl, {
            action:     'wwps_reset_token',
            nonce:      wwpsAdmin.nonce,
            project_id: projectId,
            type:       type,
        }).done(function(res){
            if (res.success && res.data && res.data.token) {
                var frontendUrl = ($('#wwps-proj-frontend').val() || window.location.origin).replace(/\/$/, '');
                var newUrl  = frontendUrl + '/?' + type + '=' + res.data.token;
                if (type === 'proof') {
                    $('#wwps-proof-url').text(newUrl);
                    $('[data-copy]').filter(function(){ return $(this).data('copy').indexOf('proof=') !== -1; }).data('copy', newUrl);
                } else {
                    $('#wwps-review-url').text(newUrl);
                    $('[data-copy]').filter(function(){ return $(this).data('copy').indexOf('review=') !== -1; }).data('copy', newUrl);
                }
                btn.prop('disabled', false).text('Reset Token');
                alert('Token reset! Update your links.');
            }
        });
    });

    // Save Settings
    $(document).on('click', '.wwps-save-settings', function(){
        var btn       = $(this);
        var projectId = btn.data('project');
        var msg       = btn.siblings('.wwps-save-msg');
        btn.prop('disabled', true).text('Saving...');

        var data = {
            action:     'wwps_save_settings',
            nonce:      wwpsAdmin.nonce,
            project_id: projectId,
        };

        if (projectId > 0) {
            data.name          = $('#wwps-proj-name').val();
            data.client_name   = $('#wwps-proj-client').val();
            data.client_emails = $('#wwps-proj-emails').val();
            data.support_email = $('#wwps-proj-support').val();
            data.frontend_url  = $('#wwps-proj-frontend').val();
        } else {
            data.overdue_hours = $('#wwps-overdue-hours').val();
        }

        $.post(wwpsAdmin.ajaxUrl, data).done(function(res){
            var label = projectId > 0 ? 'Project' : 'Global';
            btn.prop('disabled', false).text('Save ' + label + ' Settings');
            if (res.success) {
                msg.fadeIn().delay(2000).fadeOut();
            }
        });
    });

    // New Project Modal
    $('#wwps-new-project-btn').on('click', function(){
        $('#wwps-new-project-modal').show();
    });
    $(document).on('click', '.wwps-modal-close', function(){
        $(this).closest('.wwps-modal').hide();
    });
    $(document).on('keydown', function(e){
        if (e.key === 'Escape') { $('.wwps-modal').hide(); }
    });

    $('#wwps-create-project-submit').on('click', function(){
        var btn = $(this);
        btn.prop('disabled', true).text('Creating...');
        $.post(wwpsAdmin.ajaxUrl, {
            action:        'wwps_create_project',
            nonce:         wwpsAdmin.nonce,
            name:          $('#np-name').val(),
            client_name:   $('#np-client').val(),
            client_emails: $('#np-emails').val(),
            support_email: $('#np-support').val(),
        }).done(function(res){
            if (res.success) {
                location.href = '?page=wwps-settings&project=' + res.data.project_id;
            } else {
                alert('Error creating project.');
                btn.prop('disabled', false).text('Create Project');
            }
        });
    });

})(jQuery);
