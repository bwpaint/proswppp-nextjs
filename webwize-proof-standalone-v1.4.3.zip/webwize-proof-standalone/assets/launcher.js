/**
 * WebWize Proof — Session Launcher
 * Always-loaded tiny script (~700 bytes). Reads the review/proof token from
 * URL params or a 7-day cookie, then dynamically loads the full proof.js.
 * This approach is cache-safe: no server-side cookie reading required.
 */
(function () {
    var MAX_AGE = 7 * 24 * 3600;

    function getCookie(name) {
        var parts = document.cookie.split(';');
        for (var i = 0; i < parts.length; i++) {
            var p = parts[i].trim();
            if (p.indexOf(name + '=') === 0) return decodeURIComponent(p.slice(name.length + 1));
        }
        return '';
    }

    function setCookie(name, val) {
        document.cookie = name + '=' + encodeURIComponent(val) +
            '; max-age=' + MAX_AGE + '; path=/; SameSite=Lax';
    }

    // 1. URL params (highest priority)
    var params = new URLSearchParams(window.location.search);
    var proof  = params.get('proof')  || '';
    var review = params.get('review') || '';

    // 2. Cookie fallback — carries the token across every page after first visit
    if (!proof)  proof  = getCookie('wwps_proof');
    if (!review) review = getCookie('wwps_review');

    if (!proof && !review) return;

    // Refresh cookies so 7-day window resets on each page visit
    if (proof)  setCookie('wwps_proof',  proof);
    if (review) setCookie('wwps_review', review);

    // Build wwpsConfig for proof.js (mirrors what PHP wp_localize_script provides)
    if (!window.wwpsConfig || !window.wwpsConfig.ajaxUrl) {
        window.wwpsConfig = {
            ajaxUrl:     window.wwpsLauncherCfg ? window.wwpsLauncherCfg.ajaxUrl  : '',
            proofToken:  proof  || '',
            reviewToken: review || '',
            mode:        review ? 'review' : 'proof',
            pageUrl:     window.location.href
                             .replace(/[?&](proof|review)=[^&]*/g, '')
                             .replace(/[?&]$/, ''),
            pageTitle:   document.title,
            nonce:       window.wwpsLauncherCfg ? window.wwpsLauncherCfg.nonce : '',
        };
    }

    // Dynamically load proof.js — avoids double-load on same page
    if (!document.getElementById('wwps-proof-script')) {
        var sc  = document.createElement('script');
        sc.id   = 'wwps-proof-script';
        sc.src  = window.wwpsLauncherCfg ? window.wwpsLauncherCfg.proofSrc : '';
        if (sc.src) document.body.appendChild(sc);
    }
})();
